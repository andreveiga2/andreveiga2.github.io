function [ ACD ] = ACD( mu, v , xH, xL, dp )


% ---------------------------------------------------------
% computes average cost different under incremental pricing ie, AC_Delta
% ---------------------------------------------------------
% INPUTS
% (mu, v) : vector of consumer types in the market
% xH xL are the levels of coverage in the two contracts
% dp is the price different between the two contracts
% ---------------------------------------------------------
% OUTPUTS
% average cost different under incremental pricing
% ie, AC_Delta at the price different dp
% ---------------------------------------------------------

[ q , buyH ] = Q( mu, v , xH, xL, dp);          % first compute demand

ACD = (xH - xL) * mean( mu(buyH) );             % compute AC_Delta
 
end



