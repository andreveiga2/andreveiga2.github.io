function [ dac, AC_H, AC_L, AC_L_tilde ] = DAC(mu, v , xH, xL, dp)


% ---------------------------------------------------------
% computes average cost different under total pricing ie, Delta_AC, and a number of auxiliary cost curves
% ---------------------------------------------------------
% INPUTS
% (mu, v) : vector of consumer types in the market
% xH xL are the levels of coverage in the two contracts
% dp is the price different between the two contracts
% ---------------------------------------------------------
% OUTPUTS
% dac: average cost different under total pricing ie, Delta_AC at the price difference dp
% AC_H = E[cH | u>p]  is the average cost among those who choose H
% AC_L = E[ cL | u<p] is the average cost among those who choose L
% AC_L_tilde = E[ c_L | u>p ] is the average cost in contract L of those that chose contract H
% ---------------------------------------------------------

[ q , buyH ] = Q( mu, v , xH, xL, dp);                      % first determine set of buyers

AC_H = xH*mean( mu(buyH) );                                 % AC_H = E[cH | u>p]

AC_L = xL*mean( mu(~buyH) );                                % AC_L = E[ cL | u<p]
if isnan(AC_L)==1; AC_L = 0; end                            % if no one purchases, define AC_L as zero

dac = AC_H - AC_L;                                          % Delta_AC

AC_L_tilde = xL*mean( mu(buyH) );                           % AC_L_tilde = E[ c_L | u>p ]

end

