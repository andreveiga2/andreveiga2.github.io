function [ dwl ] = DWL( mu, v , xH, xL, dp)
 

% ---------------------------------------------------------
% computes dead weight loss at a given price difference between the two contracts 
% ---------------------------------------------------------
% INPUTS
% (mu, v) : vector of consumer types in the market
% xH xL are the levels of coverage in the two contracts
% dp is the price different between the two contracts
% ---------------------------------------------------------
% OUTPUTS
% dead weight loss in the market at the price different dp
% ---------------------------------------------------------


[ q , buyH ] = Q( mu, v , xH, xL, dp);          % first compute set of buyers

WW = v * (1 - ( (1-xL)^2 ) )*(1/2);                     % welfare if chosen L

WW( buyH ) = v(buyH) * (1 - ( (1-xH)^2 ) )*(1/2);           % for those that chose H, replace their welfare with welfare in contract H

W_FB = ( 1 - ( (1-xH)^2 ) )*(1/2)*mean(v);                      % FB welfare: everyone gets plan H

dwl = W_FB - mean(WW) ;                                     % dead weight loss 

end

