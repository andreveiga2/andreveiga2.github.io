

% ------------------------------------------------------------------------
%         Pricing Institution and the Cost of Adverse Selection
%                               Matlab Code                
% ------------------------------------------------------------------------


clear 


%% setup contracts

xH = 0.9; xL = 0.6;                                     % generosity of the two contracts


%% compute DWL for different values of rho
    
RHOs = linspace( -0.999, 0.999, 20)';                               % values of rho to consider
[ P_INC, P_TOT, DWL_INC, DWL_TOT ] = deal ( NaN(size(RHOs)) ) ;             % vectors of equilibrium prices and DWL to be populated

opts  = optimset('Display', 'off','TolX',1e-20,'TolFun',1e-20,'MaxIter',1000000, 'MaxFunEvals', 10000);             % optimization options
ub = 20000; lb = 0 ; guess = 5000;                                                                      % optimization options

for r=1:numel(RHOs)       % loop through values of rho

    display(['Computing graph of DWL as function of rho, iteration ' num2str(r) ' of ' num2str(numel(RHOs)) '...'])
    rho = RHOs(r); K = 300; [mu, v] = consumers(K, rho);                                                                % generate consumers according to the current value of rho; smooth graph requires K>250
    
    P_TOT(r) = fmincon( @(p) ( DAC( mu, v , xH, xL, p) - p )^2, guess, [], [], [], [], lb, ub, [], opts);               % find equilibrium price under total price
    DWL_TOT(r)  = DWL(mu, v , xH, xL, P_TOT(r));                                                                        % DWL under total pricing
    
    P_INC(r) = fmincon( @(p) ( ACD(mu, v , xH, xL, p) - p )^2, guess, [], [], [], [], lb, ub, [], opts);                    % find eql price under incremental pricing
    DWL_INC(r)  = DWL(mu, v , xH, xL, P_INC(r));                                                                            % DWL under incremental pricing

end



clf
plot(RHOs, DWL_TOT,'-x', RHOs, DWL_INC,'-o');                          % graph of DWL as a function of market correlation
legend('DWL TP','DWL IP','Location','Best'); 
title([ 'DWL under the two regimes' ]); xlabel('\rho');
set(gcf, 'PaperPosition', [-.2 -.1 5 5], 'PaperSize', [4.4 4.8]); 
saveas(gcf,strcat('DWL.pdf'));

matrix = [ RHOs P_TOT DWL_TOT P_INC DWL_INC];                               % group all results into a matrix
csvwrite(strcat('institutions_DWL.csv'), matrix);                           % save results to a CSV file



%% GRAPH 1:  equilibrium (showing ACD, DAC, MC and P)

rho = 0.65; K=200; 
DP = logspace(0, 4.7, 40);                                   % vector of prices to be considered

[ Q, DAC, ACD, MC, AC_H, AC_L, AC_L_tilde ] = outputs( xH, xL, K, rho, DP );            % producing all output curves

clf; plot(Q, DP,'-x', Q, DAC,'-o', Q, ACD,'-s', Q, MC,'-d'); 
xlabel('q'); title(['Equilibria under TP and IP, \rho=' num2str(rho)]); 
axis([0 1 0 20000]);
legend('\Delta P','\Delta AC','AC_\Delta','MC_{\Delta}','Location','Best');
set(gcf, 'PaperPosition', [-.2 -.1 5 5], 'PaperSize', [4.4 4.8]);
saveas(gcf,strcat(['Eql.pdf']));



%% GRAPH 2: showing MC_H and MC_L, AC_H and AC_L and AC*_L

MC_H = ( xH/(xH-xL)) * MC ;  MC_L = ( xL/(xH-xL)) * MC ;

clf; plot(Q, AC_H, '-x', Q, AC_L, '-o', Q, AC_L_tilde,'-s'); xlabel('q');
title(['Average Costs, \rho=' num2str(rho)]); 
l= legend('$AC_H$', '$AC_L$', ['$\widetilde{AC_{L}}$']); set(l,'Interpreter','Latex');
set(gcf, 'PaperPosition', [-.2 -.1 5 5], 'PaperSize', [4.4 4.8]);
saveas(gcf,strcat(['ACs.pdf']));



return


