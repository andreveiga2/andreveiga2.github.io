function [ mc ] = MC( Q, ACD )


% ---------------------------------------------------------
% computes marginal cost where MC = the derivative of total cost,  Q*AC_Delta(Q),  with respect to Q
% ---------------------------------------------------------
% INPUTS
% Q : vector of quantities demanded for contract H
% ACD : vector of AC_Delta at each quantity 
% ---------------------------------------------------------
% OUTPUTS
% marginal cost at each quantity
% ---------------------------------------------------------

qACD = Q.*ACD;          % total cost
mc = gradient(qACD)./gradient(Q);


end

