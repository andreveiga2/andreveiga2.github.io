function [ Q , buyH ] = Q( mu, v , xH, xL, dp)


% ---------------------------------------------------------
% produces a vector of consumer decisions and overall demand
% ---------------------------------------------------------
% INPUTS
% (mu, v) : vector of consumer types in the market
% xH xL are the levels of coverage in the two contracts
% dp is the price different between the two contracts
% ---------------------------------------------------------
% OUTPUTS
% buyH is a vector where an entry =1 signifies that the consumer
% with the corresponding type (mu,v) purchase contract H
% Q is the share of consumers choosing plan H
% ---------------------------------------------------------

gH = (1/2)*( 1 - ( (1-xH).^2 )); uH = mu*xH + gH.*v - dp;       % WTP for contract H
gL = (1/2)*( 1 - ( (1-xL).^2 )); uL = mu*xL + gL*v;             % WTP for contract L

buyH = ( uH >= uL );            % the decisions of each individual

Q    =   mean( buyH );          % demand

end

