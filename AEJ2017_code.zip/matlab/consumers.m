function [ mu, v ] = consumers( K, rho )

% ---------------------------------------------------------
% simulates consumer types following a bivariate lognormal distribution
% ---------------------------------------------------------
% INPUTS
% K : K^2 consumers are generated
% rho is the correlation between risk and risk aversion in
%   the underlying gaussian distribution
% ---------------------------------------------------------
% OUTPUTS
% mu is a vector of risk types
% v is a vector if insurance values
% ---------------------------------------------------------


%% market statistics

mean_v = 11; var_v = 1.2; sd_v = sqrt(var_v);
mean_mu = 8.4; var_mu = 0.76; sd_mu = sqrt(var_mu);


%% generating consumers

mu  = NaN(K^2,1);                                   % pre-allocating memory for K^2 consumers with 2D types
v   = NaN(K^2,1);

uu = linspace( 1/K, 1-(1/K), K)';                   % vector of K evenly spaced points within (0,1)

v_base = logninv(uu, mean_v, sd_v);                 % baseline vector of v's, will be repeated K times

for k=1:K                           % for each value of v, generate corresponding values of mu conditional on v 
    
    v_k = v_base(k);
    
    mean_mu__v      = mean_mu + rho * sqrt(var_mu/var_v) * ( log( v_k ) - mean_v ) ;                % E[mu| v]
    var_mu__v       = (1 - rho^2) * var_mu;                                                         % V[mu|v]
    sd_mu__v        = sqrt(var_mu__v);

    mu_k = logninv( uu, mean_mu__v, sd_mu__v );      % vector of mu, lognormal with mean E[mu|v] and corresponding standard deviation
    
    v(  K*(k-1)+1 : K*k, 1) = v_k*ones(K,1) ;
    mu( K*(k-1)+1 : K*k, 1) = mu_k ;                   % stacking up the results to obtain K^2 consumers
                                                     % for each value of mu_k, K values of v are generated                                         
end




end

