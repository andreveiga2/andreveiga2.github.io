function [ q, dac, acd, mc, ac_h, ac_l, ac_l_tilde ] = outputs( xH, xL, K, rho, DP )


% ---------------------------------------------------------
% computes a number of outputs for a given market, namely demand, average cost under each pricing regime
% marginal cost and other auxiliary cost curves
% ---------------------------------------------------------
% INPUTS
% K : K^2 consumers are simulated to compute the market curves
% xH xL are the levels of coverage in the two contracts
% DP is a vector of price differences between the two contracts
% rho is the correlation between mu and v in the gaussian distribution used to generate the lognormally distributed types
% ---------------------------------------------------------
% OUTPUTS
% q : total demand in the market at each dp
% dac : Delta_AC, the average cost difference under total pricing
% acd : AC_Delta : the average cost difference under incremental pricing
% MC : marginal cost
% ac_h = E[cH | u>p]  is the average cost among those who choose H
% ac_l = E[ cL | u<p] is the average cost among those who choose L
% ac_l_tilde = E[ c_L | u>p ] is the average cost in contract L of those that chose contract H 
% ---------------------------------------------------------


%% generate consumers

[mu, v] = consumers(K, rho);                                               % generate K^2 consumers in HHW market, K=400 makes smooth MC in 25s, K=500 isnt much better in 38s

%% pre- allocate memory

dac = NaN(size(DP)); 
acd = dac;  
q = dac;          
ac_h = dac;
ac_l = dac;
ac_l_tilde = dac;


%% generating the output curves for each level of price different in the vector DP

for j =1:numel(DP)
    dp = DP(j);                                                                     % price difference between plans    
    [ dac(j), ac_h(j), ac_l(j), ac_l_tilde(j) ]  = DAC(mu, v , xH, xL, dp);         % obtain DAC, AC_H, AC_L and AC_L_tilde
    acd(j)  = ACD(mu, v , xH, xL, dp);                                              % obtain Delta_AC
    q(j)    = Q(mu, v , xH, xL, dp);                                                    % obtain demand Q
end

mc = MC(q, acd) ;       % generate marginal cost



end

