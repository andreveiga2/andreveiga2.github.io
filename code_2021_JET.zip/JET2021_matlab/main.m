
% --------------------------------------------------------------------------------
%                      AG Equilibirum with unbounded costs
%                           John Levy and Andre Veiga
%                               Code by Andre veiga
% --------------------------------------------------------------------------------


% the function find_RS_eql() is used frequently. The function finds the equilibrium and is presented at the
% end of this file



%% folders

clear
beep off;
warning('on','all');                    % warnings


%% folders

mkdir('output')
delete('output/*')
save_folder = 'output/';


%% insurance surplus

% expression for insurance surplus above mean risk
% insurance surplus
g = @(x) (1/2)*(1-(1-x)^2);


%% setup for graphs


max_mu = 1e6;
nr_n = 400;   % number of individuals to simuate
mu = linspace(0, max_mu, nr_n)';    % simulate mu
v = mu.^1.15;  % simulate v as a function of mu


% graph options common to all graphs (line width, etc)
line_width = 3;
j1 = 'LineWidth';
j2 = line_width;
j6 = 'Location';
j7 = 'Best';





%% Figure 7

% Graph for Figure 7, showing that full insurnace is in the support of the
% equilibrium

% First, simulate individuals and compute equilibrium.
% Second, plot equilibrium price for x < x_1
% Plot the break-evel line for the individual with type mu** = max( mu | buy x<x^{bar})
% Plot indifference curves for a few individuals slightly below this type mu**


% setup graph
[rows,cols,pp] = deal(1,1,0); clf
[ x_eql, p_eql, ~ ] = find_RS_eql(mu, v);   % compute eql for given types
i1 = round(nr_n*0.93);      % index of top contract to be graphed


% plot eql price
pp=pp+1; subplot(rows,cols,pp);
plot(x_eql(1:i1),p_eql(1:i1),j1,j2); hold on;
ylabel('p(x)'); 
xlabel('x');
ylim([0,max(p_eql)]);
hold on;


% plot break-even line for type mu**
xx = linspace(0,1,50);
plot(xx, mu(i1)*xx,'--'); hold on;


% plot 3 indifference curves for types nearby type mu**
for tp1 = i1 - round( nr_n*[0.01, 0.05, 0.09] )
    plot_indiff( mu(tp1), v(tp1), x_eql(tp1), p_eql(tp1));
end


i2 = round(nr_n*0.995);
scatter(x_eql(i2), x_eql(i2)*mu(i1), 70,'r', 'filled');

% draw lines at points (x1,p1) and (x2,p2)
draw_2_lines(x_eql(i1),p_eql(i1));
draw_2_lines(x_eql(i2),mu(i1)*x_eql(i2));

% draw values on x axis (horizontal)
xticks([0, x_eql(i1), x_eql(i2), 1])
xticklabels({'0','x_1','x_2','1'})

% draw values on p axes (vertical)
yticks([0, p_eql(i1), mu(i1)*x_eql(i2)])
yticklabels({'0','p(x_1)','p(x_2)'})

% save graph to file
legend('price of purchased contracts','break-even line for highest \mu',j6,j7)
sgtitle(['Full Insurance in Support of Equilibrium']);
filename = 'G5';
mysave( gcf, save_folder, filename , [1,2] );







%% Figure 1 (AG eql with 2 types)

% AG equilibrium in the classical RS market with 2 types.


v_one = 10000;
mu = [5000, 10000]; % two risk types mu
v = v_one*ones(size(mu));   % both types have the same level of risk aversion
[X, P, UU] = find_RS_eql(mu, v);   % find equilibrium, including the utility of each individual in equilibrium UU
XX = linspace(0,1,50);    % 50 contracts uniformely distributed on [0,1], used to graph indifference curves

% setup for graph
[rows, cols, pp] = deal(1,1,0); clf

% loop over each type
for j=1:numel(mu)
    [ muj, vj, xj, uj, pj ] = deal( mu(j), v(j), X(j), UU(j), P(j));
    PP = NaN(size(XX));
    
    for i=1:numel(XX)
        % compute the indifference curve for each individual, ie the price
        % that would leave the individual indifferent between that contract
        % and what she obtains in equilibrium, uj
        PP(i) =  wtp(XX(i), muj, vj) - uj;
    end
    
    plot(XX, PP); hold on    % plot indifference curve for each type
    scatter(xj, pj, 100, 'r', 'd', 'filled')   % plot chosen contract for each type
    ylim([0, max(PP)])
    
    yj = linspace(0,xj);
    plot(yj, yj.*muj,'k--')   % plot break even line for each type
    ylabel('Price p')
    xlabel('Coverage x')
end

sgtitle(['AG equilibrium with 2 types'])
filename = 'AG_2types';
mysave( gcf, save_folder, filename , 2*[rows,cols] );






%% Figure 2: existence and non-existence depend on v^alpha


% computes equilibria showing that, when v increases with mu, equilibria
% converge as max(mu) increases


log_mean = log(6000);
log_sd = 1;


% opt determines the environment: whether eql will exist or not
% if opt==1, eql does not exist
% if opt==2, equilibrium does exist
for opt=[1,2]
    
    
    % set the max values of mu depending on the option
    if opt==1
        MAX_MU = [1, 2, 3, 4, 5];
    elseif opt==2
        MAX_MU = [5, 10, 15, 20, 25];
    end
    
    % setup for graph
    [rows,cols,pp] = deal(1,1,0); clf
    LOSS = NaN(size(MAX_MU))';
    
    for i = 1:numel(MAX_MU)
        max_mu_i = MAX_MU(i);
        nr_individuals = 5000;
        
        % gnerate risk types mu using log spacing, otherwise curve wont be built for low x
        % notice that min(mu)=1
        mu = logspace(0, max_mu_i, nr_individuals)';
        
        legend_location = 'Best';
        if opt==1
            fixed_v = 100000;
            v = fixed_v*ones(size(mu));
            legend_location = 'south';
        elseif opt==2
            v_exponent = 1.2;
            v = mu.^v_exponent;
        else
            error('option not feasible')
        end
        
        % find eql
        [ X, P ] = find_RS_eql(mu, v);
        
        % plot prices for this equilibrium
        plot(X,log(P));
        ylabel('log(p)');
        xlabel('Coverage x');
        legend(make_leg('log_{10}(\mu_{max})=', MAX_MU), 'Location', legend_location);
        hold on;
    end
    
    % options for graph title and file name
    if opt==1
        sgtitle(['\nu=' num2str(fixed_v)]);
        filename = 'RS_non_exist';
    elseif opt==2
        sgtitle(['\nu=\mu^{' num2str(v_exponent) '}']);
        filename = 'RS_exist';
    end
    
    mysave( gcf, save_folder, filename , 1.5*[rows,cols] );
    
end



return

















%%

















%%



function y = wtp(x, mu, v)
% gross willingness to pay of an individual (not including price)
y =  mu.*x + (1-((1-x).^2))*(1/2).*v;
end







function [ X, P, UU ] = find_RS_eql(mu, v)


% DESCRIPTION:
% finds the RS eql
% output: contracts X, prices P, and utility of each at the chosen contract
% UU

% checks on inputs
if nargin~=2; error('....'); end
if ~isequal(size(mu), size(v)); error('...'); end

% sort types mu,v by ascending order
[mu, mu_sort_order]= sort(mu,'ascend');
v = v(mu_sort_order);

% processs inputs
N = numel(mu);

% pre-allocate memory
[ X, P, UU] = deal( NaN(N,1));

% utility function
g = @(x) (1/2)*(1 - (1-x)^2);
U = @(mu,v,x,p) x*mu + g(x)*v - p;

% first step: highest type chooses full insurance
X(N) = 1;           % last type gets full insurance
P(N) = X(N)*mu(N);      % full insurance breaks even
UU(N) = (1/2)*v(N);     % utility of top type

% proceed sequently backwards through the types and find the contract that
% makes each type indifferent. Given the functional forms, this amounts to
% solving a quadratic equation
for i = N-1:-1:1
    mu_i = mu(i); % type under study
    
    % finding the contract chosen by type mu_i corresponds to solving a
    % quadratic equation of the type ax^2 +bx+c=0, where
    a = -v(i+1)/2;
    b = (mu(i+1) - mu_i) + v(i+1);
    c = - UU(i+1);
    r = roots([a,b,c]);
    
    X(i) = r(2);    % chosen contract
    P(i) = X(i)*mu_i;  % actuarily fair price for this contract
    UU(i) = U(mu_i, v(i), X(i), P(i)); % utility of type mu_i at her chosen contract
end


end






function [pp_j] = plot_indiff( mu, v, x, p  )
% plots indifference curve of type (mu, v) through point (x, p)
xx = linspace(0,1,30);
uj = x*mu + (1/2)*(1-(1-x)^2)*v - p;
pp_j = wtp( xx, mu, v) - uj;
plot(xx, pp_j); hold on;
scatter(x, p, 70,'r', 'filled'); hold on;
end



function []=draw_2_lines(x,p)
% draws two dashed lines from the axes to the point (x,p); used in several
% graphs
line([x,x],[0,p], 'LineStyle','--', 'Color','black')
line([0,x],[p,p], 'LineStyle','--', 'Color','black')
scatter(x, p, 70, 'r', 'filled');
end







