function [ y ] = make_leg( str, vec)


% input is 
% str : a single string 
% vec: a 1xN or Nx1 vector of numbers
% output should be 
% vector of strings or an cell array of strings such that it can be input into legend(.) 
% and be the legend in a graph
% for instance, 
% yy = make_leg('\alpha', [0.1, 0.2, 0.3]), then 
% legend(yy) = legend('\alpha=0.1', '\alpha=0.2','\alpha=0.3') 


% Return error message if input is not a vector
if size(vec,1)>1 && size(vec,2)>1
    disp('Need 1xN or Nx1 vector of numbers')
    return
end


vec_str=cellfun(@num2str,num2cell(vec),'UniformOutput',false);
% Making a cell of strings from a matrix is apparently not trivial
% This solution is from the following Matlab forum thread:
% https://uk.mathworks.com/matlabcentral/newsreader/view_thread/156758


% str is just a single cell, but strcat still puts this in front of 
% every element of vec_str
% the resulting y is a cell array of strings
y=strcat(str,vec_str);

%%

% add automatic ..'Location','Best'
% not sure it really works...
% JJ = numel(y);
% y{JJ+1} = 'Location';
% y{JJ+2} = 'Best';


end

