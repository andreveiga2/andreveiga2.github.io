function [ ] = mysave( gcf, folder_name, file_name, dimensions)


% this function saves a graph called gcf to a specified folder, with a specified name
% and re-sized the graph as well
% It can be used, for instance, like this:
% [rows, cols] = deal(1,2);
% subplot(rows,cols,1); plot(x1);
% subplot(rows,cols,2); plot(x2);
% mysave( gcf, save_folder, 'this_Graph.pdf', [rows,cols]);


%% check on inputs

if nargin>4
    error('Too many input arguments');    
end


%% how much to streth figures

% how much to stretch the graph
% this is a constant that is applied everywhere below
stretch = 2;                

%% missing filename and/or folder name

% what to use as file name when file name is missing
if isequal(file_name,[])
    file_name = '[missing_filename]'; 
end

% if folder name is missing, this will save to the current  working folder
if isequal(folder_name,[])
    folder_name = '';
end


%% If nr=[], get nrows and ncols from gcf structure

if nargin==3 || isequal(dimensions,[])
    ax = findobj(gcf,'type','axes');
    % get(ax,'position')
    pos = cell2mat( get(ax,'position') );
    nrows = numel(unique(pos(:,2))); % same Y positions
    ncols = numel(unique(pos(:,1))); % same X positions
    
elseif numel(dimensions)==2
    nrows = dimensions(1);
    ncols = dimensions(2);
    
    % If only 1 value specified then assume this is number of columns
    % Default value for height (i.e. number of rows) is 1
elseif numel(dimensions)==1 
    nrows = 1; 
    ncols = dimensions(1); 
    
elseif numel(dimensions)>2
    error('numel(nr)>2 ');
    
end
    
%% stretch the graph by constrant stretch

n1 = stretch*nrows;
n2 = stretch*ncols;

%% save the graph 

set(gcf, 'PaperPosition', [0 0 5*n2 5*n1]);
set(gcf, 'PaperSize', [5*n2 5*n1]);

real_file_name = strcat( file_name , '.pdf');
full_filename = fullfile( folder_name,'/', real_file_name);

if isequal(folder_name,'')
   full_filename = fullfile(real_file_name); 
end
    
saveas( gcf, full_filename);

end

