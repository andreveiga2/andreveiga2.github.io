% --------------------------------------------------------------------------------
%                      AG Equilibrium with unbounded costs
%                           John Levy and Andre Veiga
%                               Code by Andre Veiga
% --------------------------------------------------------------------------------




The function make_leg.m helps create legends for graphs.
The function mysave.m is used for saving images to files. 
It should be kept on the same folder as main.m.

Run the file main.m on Matlab (version R2020b or later). 
The rest of routines are included therein.