

Price Discrimination in Selection Markets
By Andre Veiga
Review of Economics and Statistics


SOFTWARE AND HARDWARE
MATLAB version 2021a
Executed on a Mac computer, 3.6 Ghz 10-Core Intel, 64 GB RAM, OS version macOS Venture



CODE DESCRIPTION
Execute the file main.m
The file main.m should be in a folder with a subfolder "output" where the graphs are saved
This will perform all simulations and save all graphs into the subfolder "outputs".
The code loops through a number of settings and, for each setting, simulates the markets and produces the relevant graphs.
Most auxiliary functions are included at the end of the file main.m and include explanations
The remaining functions should be included in the same folder as main.m
