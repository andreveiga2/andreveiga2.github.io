function [ varargout ] = deal_cols(MATRIX)

% deals columns of matrix input as vectors of outputs

if nargout>size(MATRIX,2)
    error('too many outputs'); 
end

% process output
for i=1:nargout
    varargout(i) = {MATRIX(:,i)};
end

end

