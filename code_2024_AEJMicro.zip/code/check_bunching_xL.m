function [ bunching_at_xL ] = check_bunching_xL(xH, xL, v, MU)

% check if there is bunching at xL, where xL is the lower bound of the
% interval [xL,xH]
% Assumes CARA-Gaussian preferences but allows for any distribution of
% types


muH = max(MU);
muL = min(MU);

% conditional for bunching
bunching_at_xL = (1/v)*(muH - muL) - log(xH/xL) + (xH - xL) > 0;

if bunching_at_xL
    fprintf('check_bunching_xL: There is PARTIAL or FULL bunching at xL.\n')
else
    fprintf('check_bunching_xL: No bunching at xL.\n')
end

end
