function [ there_is_bunching_at_zero ] = check_bunching_zero(xL, v, MU, pL)

% check if there is bunching at zero
muL = min(MU);

there_is_bunching_at_zero = g(0)*v - muL*xL - g(xL)*v + pL < 0;

if there_is_bunching_at_zero
    fprintf('There is bunching at x=0.\n')
else
    fprintf('No bunching at x=0.\n')
end


end
