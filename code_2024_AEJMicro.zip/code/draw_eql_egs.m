function [] = draw_eql_egs( output_path )


% draws examples of each type of equilibria(eg, dispersive, PPPP, etc)

v = 25;
nr_indiv_base = 2010;

% benchmark, rothschild-stiglitz eql (xL=0)
MU_here = linspace(100, 150, nr_indiv_base);
[xH_here, xL_here ] = deal(0.95, 0 );
draw_eql_no_zero(xH_here, xL_here, v, MU_here, output_path, 'eql_benchmark');


% equilibrium where x=0 is not allowed (T is large)
MU_here = linspace(20, 150, nr_indiv_base);
[xH_here, xL_here ] = deal(0.95, 0.05 );
draw_eql_no_zero(xH_here, xL_here, v, MU_here, output_path, 'eql_0out');



% equilibrium where x=0 is allowed
T = 0;
MU_here = linspace(20, 150, nr_indiv_base);
[xH_here, xL_here ] = deal(0.95, 0.05 );
draw_eql_w_zero(xH_here, xL_here, v, MU_here, T, output_path, 'eql_0in');


end
