function [ mu_star_up, x_star ] = draw_eql_no_zero(xH, xL, v, MU, output_path, file_name)


muH = max(MU);
muL = min(MU);
nr_x_points = 500;

[ mu_star_up, ~, x_star, ~, ~] = find_eql_nozero(xH, xL, v, MU, nr_x_points);
if all(isnan( [ mu_star_up, x_star]))
    fprintf('draw_eql_no_zero: Cannot make eql graph\n')
    return
end


nr_points = 12;
x_upper_range = linspace(x_star, xH, nr_points);
mu_upper_range = find_tau(xH, v, muH, x_upper_range); 


mu_lower_range = linspace(muL, mu_star_up, nr_points);
x_lower_range = xL*ones(size(mu_lower_range));


set(gca,'TickLabelInterpreter','latex')
set(groot,'defaulttextinterpreter','latex');  
set(groot, 'defaultAxesTickLabelInterpreter','latex');  
set(groot, 'defaultLegendInterpreter','latex');

y_tick_vec =  [0, xL, x_star, xH, 1] ;
y_tick_label = {'$0$','$\underline{x}$','$x*$','$\overline{x}$','$1$'} ; 

x_tick_vec = [0, muL, mu_star_up, muH] ;
x_tick_label = {'$0$','$\underline{\mu}$','$\mu^*$','$\overline{\mu}$'} ;
    
    
if xL==0
    y_tick_vec = [xL, x_star, xH, 1];
    y_tick_label = {'$\underline{x}=0$', '$x^*$', '$\overline{x}$','$1$'} ;
end

% x axis ticks (variable is mu)
if muL==mu_star_up
    x_tick_vec = [0, mu_star_up, muH] ;
    x_tick_label = {'$0$', '$\underline{\mu}=\mu*$', '$\overline{\mu}$'} ;
end


clf
[rows,cols,pp] = deal(1,1,0);



pp=pp+1; subplot(rows,cols, pp);
hold on
plot(mu_upper_range, x_upper_range,'-o'); 
if muL<mu_star_up
    plot(mu_lower_range, x_lower_range,'-d'); 
end

% exogenous variables in black
yline(xH,':k')
yline(xL,'-.k')
xline(muL,':k')

% endogenous variables in red
yline(x_star,'--r')
xline(mu_star_up, '--r')

% y ticks
yticks( y_tick_vec);
yticklabels( y_tick_label)

%  x ticks
xticks( x_tick_vec )
xticklabels( x_tick_label )   

% axes limits
ylim([0,1])
xlim([0,muH])
title('$\sigma(\mu)$')
xlabel('$\mu$')
ylabel('$x$')
legend('separating', 'pooling at $x=\underline{x}$', 'Location', 'Best', 'interpreter', 'latex')
if muL==mu_star_up
    legend('separating', 'Location', 'Best', 'interpreter', 'latex')
end



mysave( gcf, output_path, file_name, 1.1*[rows,cols])


end













