function [ mu_star_up, x_star, mu_star_down ] = draw_eql_w_zero(xH, xL, v, MU, T, output_path, file_name)



muH = max(MU);
muL = min(MU);
nr_x = 500;

[ mu_star_up, mu_star_down, x_star, ~, ~] = find_eql_with_zero(xH, xL, v, MU, nr_x, T);
if all(isnan( [ mu_star_up, x_star, mu_star_down ]))
    fprintf('draw_eql_w_zero: Cannot make eql graph\n')
    return
end

% find (mu,x) pairs in the upper range where x=sigma(mu), ie mu=tau(x);
% it's easier to start from x because the functino find_tau is fast and does not require
% solving anything
nr_points = 12;
x_upper_range = linspace(x_star, xH, nr_points);
mu_upper_range = find_tau(xH, v, muH, x_upper_range);



mu_mid_range = linspace(mu_star_down, mu_star_up, nr_points);
x_mid_range = xL*ones(1,nr_points);

mu_low_range = linspace(muL, mu_star_down, nr_points);
x_low_range = 0*ones(1,nr_points);

cond_bunch_xL = MU<mu_star_up & MU>mu_star_down;
MU_bunch_xL = MU( cond_bunch_xL );
share_bunching_xL = mean( cond_bunch_xL );
share_bunching_zero = mean( MU<=mu_star_down );
share_separated = 1 - share_bunching_xL - share_bunching_zero;



set(gca,'TickLabelInterpreter','latex')
set(groot,'defaulttextinterpreter','latex');  
set(groot, 'defaultAxesTickLabelInterpreter','latex');  
set(groot, 'defaultLegendInterpreter','latex');



clf
[rows,cols,pp] = deal(1,1,0);






pp=pp+1; subplot(rows,cols, pp);
hold on
plot(mu_upper_range, x_upper_range,'-o');
plot(mu_mid_range, x_mid_range,'-d');
plot(mu_low_range, x_low_range,'-s');

% lines for exogenous variables in black
yline(xH,':k')
yline(xL,'-.k')
xline(muL, ':k')

% lines for endogenous variables in red
yline(x_star,'--r')
xline(mu_star_up, '--r')
xline(mu_star_down, '--r')

% other graph options
ylim([0,1])
xlim([0,muH])
ylabel('$x$')
xlabel('$\mu$')

% ticks on the y axis
set(gca,'TickLabelInterpreter','latex')
yticks([0, xL, x_star, xH, 1]);
yticklabels({'$0$','$\underline{x}$','$x^*$', '$\overline{x}$', '$1$'})
xticks([0, muL, mu_star_down, mu_star_up, muH])
xticklabels({'$0$', '$\underline{\mu}$', '$\mu_{*}$','$\mu*$','$\overline{\mu}$'})
legend('separating', 'pooling at $x=\underline{x}$', 'pooling at $x=0$', 'Location', 'Best', 'interpreter','latex')
title('$\sigma(\mu)$')


if 1==0
% histogram of type distribution
pp=pp+1; subplot(rows,cols, pp)
nr_bins = 15;
bin_edges = linspace(min(MU), max(MU), nr_bins+1);
histogram(MU, bin_edges )
title('histogram \mu')
xlabel('\mu')
% ylabel('PDF')




% graph of price
pp=pp+1; subplot(rows,cols, pp);
p_u = mu_upper_range.*x_upper_range;
plot(x_upper_range, p_u, '-o'); hold on
pL = xL*mean( MU_bunch_xL );
scatter(xL, pL, 80, 'filled')
scatter(0, 0, 80, 'filled')
xlabel('x')
title('p(x)')
legend('$p(x)$', '$p(\underline{x})$', '$p(0)$', 'Location', 'Best', 'interpreter','latex')




pp=pp+1; subplot(rows,cols, pp);
X = categorical({'$0$', '$\underline{x}$', '$\sigma(\mu)>\underline{x}$'});
X = reordercats(X,{'$0$', '$\underline{x}$', '$\sigma(\mu)>\underline{x}$'});
Y = [share_bunching_zero, share_bunching_xL, share_separated ] ;
bar(X,Y)
title('Share buying')
end




if 1==0
    bin_width_for_both = round((muH-muL)/20);
    pp=pp+1; subplot(rows,cols, pp);
    hold on
    h1 = histogram(MU(MU>=mu_star_up));
    h1.Normalization = 'probability';
    h1.BinWidth = bin_width_for_both;
    h2 = histogram(MU( MU<mu_star_up & MU>mu_star_down));
    h2.Normalization = 'probability';
    h2.BinWidth = bin_width_for_both;
    h3 = histogram(MU( MU<mu_star_down));
    h3.Normalization = 'probability';
    h3.BinWidth = bin_width_for_both;
    ylabel('probability')
    xlabel('\mu')
    title( {['% pooling at xL: ' ns(100*share_bunching_xL)] , [ '% pooling at 0: ' ns(share_bunching_zero) ]})
end

% these two graphs are the levels of utility of the threshold types, to
% check graphically the indifference conditions
if 1==0
    pp=pp+1; subplot(rows,cols, pp);
    p_star = x_star*mu_star_up;
    pL = xL*mean(MU( MU<mu_star_up & MU>=mu_star_down));
    u_mu_star_up_1 = util(mu_star_up, v, x_star, p_star);
    u_mu_star_up_2 = util(mu_star_up, v, xL, pL);
    pH = xH*max(MU);
    u_mu_star_top = util(mu_star_up, v, xH, pH);
    utilities_mu_star = [u_mu_star_up_1, u_mu_star_up_2, u_mu_star_top];
    utility_labels = categorical({'u(p*,x*)','u(pL,xL)','u(p_1,x_1)'}) ;
    utility_labels = reordercats(utility_labels);
    bar(utility_labels, utilities_mu_star);
    title(['utility of type \mu*'])
    
    
    
    pp=pp+1; subplot(rows,cols, pp);
    u_mu_star_down_1 = util(mu_star_down, v, xL, pL);
    u_mu_star_down_2 = util(mu_star_down, v, 0, 0);
    pH = xH*max(MU);
    u_mu_star_top = util(mu_star_down, v, xH, pH);
    utilities_mu_star = [u_mu_star_down_1, u_mu_star_down_2, u_mu_star_top];
    utility_labels = categorical({'u(p*,x*)','u(0,0)','u(p_1,x_1)'}) ;
    utility_labels = reordercats(utility_labels);
    bar(utility_labels, utilities_mu_star);
    title(['utility of type \mu_*'])
end

mysave( gcf, output_path, file_name, 1.1*[rows,cols])

end













