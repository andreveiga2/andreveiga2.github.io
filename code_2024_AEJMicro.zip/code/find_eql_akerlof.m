function [ mu_star_up, mu_star_down, x_star, w_tot, min_val] = find_eql_akerlof(xL, v, MU, T)



tic_find_eql_akerlof = tic;


%% checks on inputs

assert(xL>=0)
assert(xL<=1)
assert( all(MU>=0) )
assert( v>=0 )
assert( T>=0 )
assert( isscalar(v) )
assert( isscalar(xL) )
assert( isscalar(T) )


%% process inputs

muL = min(MU);
muH = max(MU);
nr_indivs = numel(MU);

%% find eql

% finds the type which is mu_star_down
% will search over all types.
% compute, for each individual ,utility from purchasing the contract minus
% the outside option (normalized to zero)

u_zero = -T ;
CUM_MEAN_MU = NaN(1,nr_indivs);
for i=1:nr_indivs
   CUM_MEAN_MU(i) = mean( MU( MU>=MU(i)));
end

PP = xL*CUM_MEAN_MU;
uL = util(MU, v, xL, PP);
U_diff = uL - u_zero;
    



make_graph = 0;
if make_graph==1
    if all(U_diff>0) || all(U_diff<0)
        [rows,cols,pp] = deal(1,1,0); clf
        pp=pp+1; subplot(rows,cols, pp)
        plot(MU, U_diff)
        yline(0)
        xlabel('\mu')
        ylabel('\Delta U')
        yline(0,'--r')
        title('Akerlof eq: cannot find')
        fprintf('Akerlof eq: cannot find \n ')
        pause(0.1)
    end
end


if all(U_diff>0)
    % all individuals purchase xH
    fprintf('Akerlof eq: everyone buys \n ')
    mu_star_down = muL;
    min_val = 0;

elseif all(U_diff<0)
    % nobody buys
    fprintf('Akerlof eq: nobody buys \n ')
    mu_star_down = muH;
    min_val = 0;

else
    % find the point at which U_diff ==0, this is the equilibrium
    [min_val, index ] = min(abs(U_diff));
    mu_star_down = MU(index);
end




%% compute welfare

% don't need x_star for welfare, just mu_star_Down
% both entries into welfare are xL, because xH=xL in lemon's markets
% to compute welfare take mu_star_up = muH
mu_star_up = muH ;
w_tot = welf(xL, xL, v, mu_star_up, mu_star_down, MU);

% in the output, make = mu_star_up = x_star = NaN
% because then it doesn't get graphed when making the graphs for
% this equilibrium
[ mu_star_up, x_star ] = deal(NaN);


%% checks on outputs

assert(mu_star_down >= muL)
assert(mu_star_down <= muH)


%% final message

fprintf('Eql Akerlof: mu*=%6.4f, crit=%6.4f, time=%6.4fs \n', mu_star_down, min_val, toc(tic_find_eql_akerlof))

end





