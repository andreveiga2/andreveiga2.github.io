function [ mu_star_up, mu_star_down, x_star, w_tot, min_val] = find_eql_nozero(xH, xL, v, MU, nr_x_points)


% finds equilibrium for mandatory purchase, ie x=0 is not allowed
% if there is no bunching or full bunching, set min_val=0, otherwise the code deduces that eql was not found



fprintf('\nFinding eql NO zero...\n')
tic_total = tic;


%% checks on inputs

assert(xH<=1 & xH>=0)
assert(xL<=1 & xL>=0)
assert(xH >= xL)
assert( all(MU>=0))
assert( v>=0)
assert( isscalar(v))

%% process inputs

muL = min(MU);
muH = max(MU);


%% check for bunching


% check if there is full bunching at xL (everyone buys xL); if there is, terminate
% then check for partial bunching. If there isn't, then there is no
% bunching, so find sigma and terminate

pL_all = xL*mean(MU);  % price of xL if all individuals buy it
full_bunching_at_xL = util(muH, v, xH, xH*muH) < util(muH, v, xL, pL_all);
atom_at_xL = check_bunching_xL(xH, xL, v, MU);

if full_bunching_at_xL
    fprintf('find_eql_nozero: FULL bunching at xL. mu*=muH, x*=xH. \n')
    [ mu_star_up, x_star, min_val ] = deal(muH, xH, 0);
    
elseif atom_at_xL==0
    % in this case, there isn't full bunching and there isn't partial
    % bunching, so zero bunching
    disp('find_eql_nozero: ZERO bunching at xL. mu*=muL, x*=sigma(muL)');
    [ sigma_muL ] = find_sigma(xH, v, [muL, muH]);
    [ mu_star_up, x_star, min_val ] = deal( muL, sigma_muL(1), 0);
    
else
    fprintf('find_eql_nozero: PARTIAL bunching at xL.\n')
    method = 1;
    % methods 1 and 5 seem to work OK
    fprintf('find_eql_nozero: using method %u.\n', method)
    if method==1
        [ mu_star_up, x_star, min_val ] = find_eql_nozero_method1(xH, xL, v, MU, nr_x_points);
    end
    
end


%% compute welfare

% to compute welfare, set mu_star_down = muL, but then set it as NaN
mu_star_down = muL;
[ w_tot  ] = welf(xH, xL, v, mu_star_up, mu_star_down, MU);

mu_star_down = NaN;


%% checks on outputs

assert( isnan(mu_star_up)==0 )
assert( isnan(x_star)==0 )
assert( isnan(min_val)==0 )
assert( mu_star_up >= muL )
assert( x_star >= xL )
assert( x_star <= xH )


%% final message

toc_total = toc(tic_total);
fprintf('Eql no zero: mu*=%6.4f, x*=%6.4f, crit=%6.4f, time=%6.4fs \n', mu_star_up, x_star, min_val, toc_total)

end











%% method 1

function [ mu_star_up, x_star, min_val ] = find_eql_nozero_method1(xH, xL, v, MU, nr_x_points)

% find the mu* corresponding to each x
% then find the pL corresponding to each mu*
% then find the mu* that's indifferent

muH = max(MU);
XX = linspace(xL, xH, nr_x_points);
MU_STAR_UP = find_tau(xH, v, muH, XX);
[ U_in_xstar, UL, cond_mean_mu ] = deal( NaN( 1, nr_x_points ));

% loop over MU_STAR_UP, compute utilities
method = 1;

if method==1
    % cannot just use cumsum on MU_STAR_UP because that does not include all types MU
    for i=1:nr_x_points
        cond_mean_mu(i) = mean( MU( MU < MU_STAR_UP(i)  ) );
    end
    
    % in the paper we call PL p^2
    PL = xL*cond_mean_mu;

    % now compute price and utility in mu*'s chosen contract (not in xL)
    p_in_xstar = MU_STAR_UP.*XX;
    U_in_xstar = util(MU_STAR_UP , v, XX, p_in_xstar);

    UL = util(MU_STAR_UP, v, xL, PL);
    
elseif method==2
    error('method currently not available')
end


% we check the difference in utility for type mu*, between contract x* and
% xL, and this should vanish
U_diff = U_in_xstar - UL;

if all(U_diff>0) 
    error('find_eql_nozero: zero pooling. This should have been caught earlier.')
    
elseif all(U_diff<0)
    fprintf('find_eql_nozero: full pooling. Setting mu*=muH, x_star=xH.\n')
    [ mu_star_up, x_star, min_val ] = deal(muH, xH, 0);
    
    make_graph = 0;
    if make_graph==1
        [rows,cols,pp] = deal(1,1,0); clf
        pp=pp+1; subplot(rows,cols, pp)
        plot(XX, U_diff); hold on; yline(0)
        title('U(x*,p*(x*))-U(xL,pL(x*))')
        pause(1)
    end
    
else
    [min_val, index ] = min(abs(U_diff));
    x_star = XX(index);
    mu_star_up = MU_STAR_UP(index);
     
end





end











