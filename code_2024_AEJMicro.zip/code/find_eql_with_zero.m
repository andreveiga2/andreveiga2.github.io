function [ mu_star_up, mu_star_down, x_star, w_tot, min_val] = find_eql_with_zero(xH, xL, v, MU, nr_x, T)


% finds equilibrium with voluntary purchase, ie, zero is an option
% xH: max overage
% xL: min coverage (apart from zero)
% v: risk aversion
% MU: vector of risk types
% nr_x: number of points in grid of x values to find eql

fprintf('\nFinding eql WITH zero...\n')

tic_total = tic;

%% process inputs

muL = min(MU);
muH = max(MU);

%% check inputs

assert(xH<=1)
assert(xL<=1)
assert(xH>=0)
assert(xL>=0)
assert(xH >= xL)
assert( all(MU>=0) )
assert( v>=0 )
assert( isscalar(v) )
assert( isscalar(xH) )
assert( isscalar(xL) )


%% check if there is pooling at xL


atom_at_xL = check_bunching_xL(xH, xL, v, MU);

if atom_at_xL == 0
    fprintf('find_eql_with_zero: NO pooling at xL. Setting mu^*=mu_*=muL, x*=sigma(muL) \n');
    [ sigma_muL ] = find_sigma(xH, v, [muL, muH]);
    [ mu_star_up, mu_star_down, x_star, min_val ] = deal( muH, muL, sigma_muL(1), 0);

else 
    fprintf('find_eql_with_zero: PARTIAL or FULL pooling at xL.\n')
    % in this setting (zero is allowed), the condition for full pooling is necessary
    % BUT NOT SUFFICIENT. check that when there is full pooling
    % the condition is satisfied
    
    method = 1;
    if method==1
        [ mu_star_up, x_star, mu_star_down, min_val ] = find_eql_with_zero_method1(xH, xL, v, MU, nr_x, T);
    end

end



%% compute welfare

[ w_tot  ] = welf(xH, xL, v, mu_star_up, mu_star_down, MU);


%% output message

toc_total = toc(tic_total);
fprintf('Eql no zero: mu*=%6.4f, mu_*=%6.4f,  x*=%6.4f, crit=%6.4f, time=%6.4fs \n', mu_star_up, mu_star_down, x_star, min_val, toc_total)

%% checks on outputs

assert( any(isnan([ mu_star_up, x_star, min_val ]))==0, 'find_eql_with_zero: some outputs NaN')

if mu_star_down<muL
    fprintf('mu_star_down<mu_L. Nobody buys 0. Setting mu_star_down=mu_L.')
    mu_star_down = muL;
elseif mu_star_down>mu_star_up
    error('mu_star_down>mu_star_up.\n')
end

end











%% method 1

function [ mu_star_up, x_star, mu_star_down, min_val ] = find_eql_with_zero_method1(xH, xL, v, MU, nr_x, T)

muL = min(MU);
muH = max(MU);


% 1) evaluate a fine grid of values of x in [xL,xH]; for each find the
% corresponding mu using mu=tau(x)
% nr_x should be quite high (around 3e4) otherwise the equilibrium functions are not smooth
XX = linspace(xL, xH, nr_x);
[MU_STAR_UP, PL1, MU_STAR_DOWN] = compute_mu_star_up_down_PL1(xH, xL, v, muH, XX, T);


% MU_STAR_DOWN is computed using T, so that when we compute
% PL2, the effect of T is also computed
PL2 = compute_pL2(xL, MU, MU_STAR_UP, MU_STAR_DOWN);
del_P = PL1 - PL2;


% remove NaNs
del_P_without_nans = del_P( ~isnan(del_P) );


% find the number of types del_P changes sign
nr_sign_changes = numel( find( diff( sign( del_P_without_nans ))));



% if there are no sign changes in del_P
if all(del_P>0) || all(del_P<0)
    assert( nr_sign_changes==0, 'nr sign changes not working properly')
    
    fprintf('find_eql_with_zero_method1: PL1, PL2 do NOT intersect. Full pooling at xL. Setting mu*=muH, x*=xH, then treat as Akerlof model with options X={0,xL}.\n')
    mu_star_up = muH;
    x_star = xH;
    [ ~, mu_star_down, ~, ~, min_val] = find_eql_akerlof(xL, v, MU, T);
    
    % check that necessary condition for full pooling at xL holds
    % type muH must prefer her assigned contract xH at the fair price, over
    % contract xL at the price that would occur if everyone chose xL
    full_bunching_at_xL = util(muH, v, xH, xH*muH) < util(muH, v, xL, xL*mean(MU));
    if full_bunching_at_xL==0
        pause_length = 0;
        message_for_graph = 'No intersection of PL1, PL2, so full pooling, but necessary condition for full pooling not satisfied.';
        make_delP_graph(XX, PL1, PL2, xL, xH, message_for_graph, pause_length)
        error( message_for_graph )
    end
    
    return
end



% if Delta_P changes sign more than once, make a graph
if nr_sign_changes>1
    message_for_graph = 'nr sign changes>1';
    fprintf('Nr sign changes=%u \n', nr_sign_changes)
    pause_length = 0;
    make_delP_graph(XX, PL1, PL2, xL, xH, message_for_graph, pause_length)
end




% fine-tune the result for x*
% as a starting value, take the point at which del_P is closest to zero
[~, x0_index] = min( abs(del_P));
x0 = XX(x0_index);
    
    
% method 2: fine-tune the final results and gets more accurate results
% takes only slightly more time
method = 2;
switch method
    
    case 1
    % take value of x0 from the grid search above
    [x_star, min_val ] = deal(x0, 0);
        
    case 2
    fzero_opts = optimset('Display', 'off', 'MaxIter', 1e6, 'MaxFunEvals', 1e6, 'TolX', 1e-20, 'TolFun', 1e-15 );
    fun_here = @(x) abs( compute_del_P(x, xL, xH, v, muH, MU, T) );
    [x_star, min_val ]= fminsearch(fun_here, x0, fzero_opts);
end
        


% assign mu_star_up, mu_star_down, pL based on the equilibrium value of x*
[mu_star_up, pL, mu_star_down] = compute_mu_star_up_down_PL1(xH, xL, v, muH, x_star, T);
fprintf('find_eql_with_zero: Found x*. Criterion=%8.6f (should be small) \n', min_val)





% must check this after finding the putative eql because the correct value of pL is needed to evaluate
% this condition. it is possible that there is bunching at xL without there
% being any bunching at zero (but it's not possible to have bunching at zero without bunching at xL)
% the condition is that the lowest type (muL) prefers xL at its price, over zero
% no_bunching_at_zero = g(0)*v - T <= muL*xL + g(xL)*v - pL;
no_bunching_at_zero = util(muL, v, 0, T) < util(muL, v, xL, pL);
if no_bunching_at_zero
    fprintf('No bunching at zero. Solving as if zero is absent, then setting mu_*=muL.  \n')
    [ mu_star_up, ~, x_star, ~, ~] = find_eql_nozero(xH, xL, v, MU, nr_x);
    mu_star_down = muL;
end




make_graph = 0;
if make_graph==1
    [rows,cols,pp] = deal(2,2,0); clf
    pp=pp+1; subplot(rows,cols, pp)
    plot(XX, MU_STAR_UP); hold on
    plot(XX, MU_STAR_DOWN); hold on
    xlabel('x*')
    ylim([0,muH])
    xlim([0,1])
    xline(xL, '--k')
    xline(xH, '--k')
    yline(muL,'--k')
    legend('\mu*', '\mu_*', 'Location', 'Best')
end



end















function [] = make_delP_graph(XX, PL1, PL2, xL, xH, message_for_graph, pause_length)

del_P = PL1 - PL2;

[rows,cols,pp] = deal(2,3,0); clf

pp=pp+1; subplot(rows,cols, pp)
plot(XX, PL1); hold on
plot(XX, PL2)
xlim([0,1])
xline(xL, ':k')
xline(xH, ':k')
xlabel('x')
legend('pL_1 from IC of \mu*', 'pL_2=x_L*E[\mu|\mu in [\mu_*,\mu*]]', 'x_L', 'x_H', 'x*', 'Location', 'Best')
title(message_for_graph)


pp=pp+1; subplot(rows,cols, pp)
plot(XX, del_P)
yline(0)
xlabel('x')
title('\Delta=P_{L1}-P_{L2}')

pp=pp+1; subplot(rows,cols, pp)
plot(XX, sign(del_P), '-o')
yline(0)
xlabel('x')
title('sign(\DeltaP)')

sign_del_P = sign(del_P);
diff_sign_del_P = diff(sign_del_P);
nr_sign_changes = numel(find(diff(sign(del_P))));
XX_short = XX(2:end);
pp=pp+1; subplot(rows,cols, pp)
plot(XX_short, diff_sign_del_P, '-o')
yline(0)
xlabel('x')
title(['\Delta sign(\DeltaP), nr changes=' num2str(nr_sign_changes)])

% check if, when Delta P changes sign, it always happens for similar values of x
x_with_sign_change = XX_short(diff_sign_del_P~=0 & isnan(diff_sign_del_P)==0);
diff_in_x_with_changes = abs( max(x_with_sign_change) - min(x_with_sign_change));
if diff_in_x_with_changes>0.1
    warning('Delta P chances sign in multiple regions. Something wrong, check graph.')
end

pause(pause_length)

end






%% compute mu_star_down and PL1


function [MU_STAR_UP, PL1, MU_STAR_DOWN] = compute_mu_star_up_down_PL1(xH, xL, v, muH, XX, T)

% compute mu_star_down and PL1
% these are always computed together so they are computed in the same function


% 1) find mu* for every x
MU_STAR_UP = find_tau(xH, v, muH, XX);

% 2) for each x and mu*=tau(x) find the price pL(x), that makes type mu* indifferent between
% her assigned contract x=sigma(mu), at price p=mu*sigma(mu) and
% the contract (xL,pL).
PL1 = xL*MU_STAR_UP - ( g(XX) - g(xL))*v;
assert( all(diff(PL1)<0), 'PL1 should be decreasing in x' )

% 3) compute the price pL for each x a different way.
% for each x, we have already found mu=tau(x) and a corresponding pL using
% the method above
% now, using this information, find compute mu_* (lower *) using incentive
% compatibility. That is, for each each x and mu*=tau(x) and pL(x),
% the type mu_* must be indifferent between the contract (pL,xL) and the
% contract (0,0)
MU_STAR_DOWN = (1/xL)*( (g(0) - g(xL))*v + PL1 - T );


% checks on outputs
assert( isequal( size(MU_STAR_UP), size(PL1)), 'wrong sizes')
assert( isequal( size(MU_STAR_UP), size(MU_STAR_DOWN)), 'wrong sizes')


end





%% compute PL2

function [PL2] = compute_pL2(xL, MU, MU_STAR_UP, MU_STAR_DOWN)


% computes price pL a second way


% 4) we have, for each x, a value of mu^*(x) and a value of mu_*(x)
% using these, compute the price pL as the average cost of those buying
% contract xL (ie, all types mu_*<mu<mu*)

% checks on inputs
assert( isequal(size(MU_STAR_UP), size(MU_STAR_DOWN)) )

% number of x points to loop over
nr_x = numel(MU_STAR_UP);
[ cond_mean_mu ] = deal( NaN(1, nr_x));
for i=1:nr_x
    buyers_xL_i = MU( MU<= MU_STAR_UP(i) & MU>= MU_STAR_DOWN(i));
    cond_mean_mu(i) = mean( buyers_xL_i );
end
PL2 = xL*cond_mean_mu;

end



%% computes difference in PL1 and PL2

function [del_P] = compute_del_P(XX, xL, xH, v, muH, MU, T)

% computes difference in PL1 and PL2, ie the price pL computed in two
% different ways

% this is used in the fine-tuning of finding x; 

% if the algorithm tries to evaluate a value of x greater than xH
% output is NaN so it tries another value without breaking
if numel(XX)==1 && XX>xH; del_P = NaN; return; end


[MU_STAR_UP, PL1, MU_STAR_DOWN] = compute_mu_star_up_down_PL1(xH, xL, v, muH, XX, T);
PL2 = compute_pL2(xL, MU, MU_STAR_UP, MU_STAR_DOWN);
del_P = PL1 - PL2;

end







