function [ SIGMA, FVALS ] = find_sigma(xH, v, MU)



% finds the choice x = sigma(mu) for a vector of individual types MU
% all individuals have the same risk aversion v
% this function assumes CARA-Gaussian preferences, but should be valid for
% all type distributions
%%%%%%%%%%%
% !!!!!!!! cannot include just a single point in MU; MU is used to compute
% muH which determines the sigma of all types. To find the sigma for a
% specific type, input:
% MU = [mu_of_interest, muH] and from the outputs take
% SIGMA(1)
%%%%%%%%%%%





%% settings

tic_all = tic;

%% checks on inputs

if any(diff(MU)<0)
    disp(MU); error('find_sigma: MU should be monotonic increasing')
end

%% processing inputs

muH = max(MU);
nr_indivs = numel(MU);


%% if it's just one type

if isequal(MU, muH)
    %  it's possible that input into find_sigma is a single type,
    % in which case, assign x*=xH
    fprintf('find_sigma: MU contains just 1 type. Setting sigma(mu)=xH. \n')
    [ SIGMA, FVALS ] = deal(xH, 0);
    return
end



%% process

% method 1 is slower but more accurate
% method 2 is faster, but the difference is small

method = 2;
if method == 1
    [ SIGMA, FVALS ] = find_sigma_method1(xH, v, MU);
elseif method ==2
    [ SIGMA, FVALS ] = find_sigma_method2(xH, v, MU);
end




%% checks on outputs

max_fval = max(abs(FVALS));
if max_fval>1e-3
    fprintf('find_sigma: max |fvals| = %u \n', max_fval)
end


if (any(isnan(SIGMA)))
    disp(SIGMA);
    error('sigma has NaNs');
end

if any(SIGMA>xH)
    error('some sigma>xH')
end



% check if sigma is reasonable.
make_graph2 = 0;
if make_graph2 == 1
    [rows,cols,pp] = deal(1,1,0); clf
    pp=pp+1; subplot(rows,cols, pp)
    plot(MU, SIGMA, '-o')
    xlabel('\mu')
    title('x=\sigma(\mu)')
    yline(xH)
end

%% exit message

toc_all = toc(tic_all);
fprintf('Found sigma for %u types in t= %6.4f.\n', nr_indivs, toc_all)


end






%%








%% different methods


function [y] = fn_vanish_at_sigma(x, mu, xH, v, muH)

if x>1
    y=NaN; return;
elseif x<0
    y=NaN; return
else
    y = muH - mu -v *( log(xH) - log(x) - xH + x)  ;
end

end




function [ SIGMA, FVALS ] = find_sigma_method1(xH, v, MU)

% parameters

small_nr = 1e-10;
nr_x = 200;  % nr of values of X to use to find starting value
fzero_opts = optimset('Display', 'off', 'MaxIter', 1e6, 'MaxFunEvals', 1e6, 'TolX', 1e-20, 'TolFun', 1e-15 );

%% process inputs

nr_indivs = numel(MU);
muH = max(MU);

%% find x=sigma(mu) for each mu

% loop through individuals and find sigma for each individual; there is no
% closed form so must solve numerically for each individual
[ SIGMA, FVALS ] = deal( NaN(size(MU)) );
for i = 1:nr_indivs
    fi = @(x) fn_vanish_at_sigma(x, MU(i), xH, v, muH);   % plug in the value of mu currently being examined

    % search for a good starting value
    XX = linspace(small_nr, 1-small_nr, nr_x);
    FF = NaN(1,nr_x);
    for j=1:nr_x
        FF(j) = fi( XX(j) );
    end

    % if there is full bunching
    if all(FF>0) || all(FF<0)
        FVALS(i) = 0;
        SIGMA(i) = xH;
    end

    [min_val, index] = min(abs(FF));   % find where the expression is closest to zero
    s_init = XX(index);

    make_graph1 = 0;
    if make_graph1==1
        clf;
        plot(XX, FF);
        yline(0);
        xline(s_init);
        title([ns(i) ':\sigma=' ns(s_init)])
        pause(1)
    end

    % fine-tune the exact value of x*
    [x_val, fval] = fzero(fi, s_init, fzero_opts);
    FVALS(i) = fval;
    SIGMA(i) = x_val;
end



end







function [ SIGMA, FVALS ] = find_sigma_method2(xH, v, MU)

% method 2 evalutes a very dense grid of values of x and then picks the
% best value from that grid. it does not do fine-tuning.

%% process inputs

nr_indivs = numel(MU);
muH = max(MU);

%% create space of contracts

% generate multiple contracts for each type
% multiple should be sufficiently high. multiple = number of contracts on
% grid / number of individuals in MU
multiple = 30;
nr_try_contracts = round(nr_indivs*multiple);
XX = linspace(0, xH, nr_try_contracts);

%% find mu for each contract

MU_STAR_FROM_TAU = find_tau(xH, v, muH, XX);

SIGMA = NaN(nr_indivs,1);
FVALS = zeros(size(SIGMA));


method = 2;
switch method
    case 1
        % method 1 is vectorialized but in fact it's SLOWER for a large
        % number of types (it creates a very large matrix)
        [~, index_i] = min( abs(MU_STAR_FROM_TAU - make_col_vec(MU)) ,[], 2 );
        SIGMA = XX(index_i);

    case 2
        for i=1:nr_indivs
            [~, index_i] = min( abs(MU_STAR_FROM_TAU - MU(i)) );
            SIGMA(i) = XX(index_i);
        end

    otherwise
        error('no such method')
end



assert( any( isnan(SIGMA))==0 )


if 1==0
    % optional graph
    clf
    plot(MU_STAR_FROM_TAU, distance_to_mu_i)
    title(['index=' ns(index_i), ', x=' ns(SIGMA(i)) ])
    pause(3)
end



do_fine_tuning = 1;
if do_fine_tuning==1
    fzero_opts = optimset('Display', 'off', 'MaxIter', 1e6, 'MaxFunEvals', 1e6, 'TolX', 1e-20, 'TolFun', 1e-15 );
    for i = 1:nr_indivs
        fi = @(x) fn_vanish_at_sigma(x, MU(i), xH, v, muH);   % plug in the value of mu currently being examined
        init_guess = SIGMA(i);
        assert( isnan(init_guess)==0 )
        [x_val, fval] = fzero(fi, init_guess, fzero_opts);


        if isnan(x_val)
            do_graph = 0;
            if do_graph==1
                XX = linspace(0, 1, 100);
                fi_evaled = fi(XX);
                clf; plot(XX, fi_evaled); hold on
                scatter(init_guess, fi(init_guess), 100, 'filled')
                yline(0)
                pause(0.1)
                title('Troubling fine-tuning \sigma')
                legend('function', 'initial guess', 'Location', 'Best')
            end
            fprintf('find_sigma: fine tuning did not work, going with grid value. \n')
            x_val = init_guess;
        end

        FVALS(i) = fval;
        SIGMA(i) = x_val;

        assert( isnan(x_val)==0 )
    end
end



end