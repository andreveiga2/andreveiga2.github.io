function [ MU_STAR ] = find_tau(xH, v, muH, XX)

% finds mu = tau(x), the threshold type mu* associated with a given threshold contract x*;
% muH = max(MU);
% xH: top contract being considered. This is not necessarily obtainable
% from XX, since XX can be a single contract for which we are interested in
% obtaining mu*
% XX : all the contracts for which mu* is to be found
% Assumes CARA-Gauss preferences but is valid for all type distributions.

%% check on inputs

max_x = max(XX);
if xH < max_x; error('xH<max(XX)');end


%% process

% this equation is a result from the equilibrium characterization, ie in
% the separating region, which type MU is purchasing each contract XX
% tau(x) is the type (mu) purchasing contract x in equilibrium
MU_STAR = muH - v*( log(xH) - log(XX) - xH + XX);

end