function [ x_star ] = find_x_star(xH, xL, v, MU)

muL = min(MU);
muH = max(MU);

% find x_star
% this equation contains only x_star
find_x_star_fn = @(x) (1-xL)^2 - (1-x)^2 - (muH - muL)*xL + v*xL*( log(xH) - log(x) + xH - x );

% search starting value for x_star on a grid
nr_x = 100;
small_nr = 0.02;
XX = linspace(small_nr, 1-small_nr, nr_x);
FF = NaN(1,nr_x);
for j=1:nr_x
    FF(j) = find_x_star_fn( XX(j) );
end
[min_val, index] = min(abs(FF));
s_init = XX(index);
fprintf('found x_init = %6.4f \n', s_init)


% fine-tune x_star using fzero and using the best value from above as a
% starting value
fzero_opts = optimset('Display', 'off', 'MaxIter', 1e6, 'MaxFunEvals', 1e6, 'TolX', 1e-20, 'TolFun', 1e-15 );
[x_star, fval] = fzero(find_x_star_fn, s_init, fzero_opts);
fprintf('fval = %u \n', fval)
fprintf('found x* = %6.4f \n', x_star)
fprintf('xH = %4.2f, xL=%4.2f  \n', xH, xL)


% graph
clf
[rows,cols,pp] = deal(1,1,0);

pp=pp+1; subplot(rows,cols, pp)
plot(XX, FF)
xline(x_star,'--b')
xline(xL, '--r')
xline(xH, '--g')
yline(0)
xlabel('x')
legend('f(x*)=0', 'x*', 'x_L', 'x_H', '0')
title(['x*=' ns(s_init) ', x_L=' ns(xL)])


% checks on outputs
if x_star<xL; error('x*<xL'); end
if x_star>xH; error('x_star>xH'); end


end
