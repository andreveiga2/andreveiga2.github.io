function [y] = g(X)
    % insurance surplus for CARA-Gauss preferences
    y = (1/2)*(1 - (1-X).^2 );
end

