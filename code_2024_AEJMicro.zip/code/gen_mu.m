function [MU, pdf_mu, dist_name] = gen_mu(muL, muH, nr_indivs, distribution_nr)

% generates various distributions of types MU

K = nr_indivs;
small_nr = 1/(K+1);
uu = linspace(small_nr, 1-small_nr, K);

mean_mu = (1/2)*(muH + muL);
std_mu = sqrt( (1/12)*(muH-muL)^2 );

% uniform
if distribution_nr==1
    dist_name = 'Uniform';
    MU = linspace(muL, muH, nr_indivs);
    pdf_mu = @(x) 1./(muH-muL) * ones(size(x));
    

    % truncated gaussian
elseif distribution_nr==2
    dist_name = 'Truncated  Gaussian';
    mean_mu = 100;
    std_mu = 10;
    MU = norminv(uu, mean_mu, std_mu);
    MU(MU<0)=[];
    MU( MU > 4* mean_mu ) = [];
    pdf_mu = @(x) normpdf(x, mean_mu, std_mu);
    
    
    
    % exponential
elseif distribution_nr == 3
    dist_name = 'Truncated Exponential';
    lambda = 34;
    [dist_name, MU, pdf_mu] = gen_mu_exponential(uu, lambda );
    MU( MU > quantile(MU, 0.90) ) = [];
    
    
    % weibull
elseif distribution_nr==4
    dist_name = 'Truncated Weibull';
    A = 40;
    B = 4;
    MU = wblinv(uu, A, B);
    MU( MU > 4* mean_mu ) = [];
    pdf_mu = @(x) wblpdf(x,A,B);
    
    
    % gamma
elseif distribution_nr==5
    dist_name = 'Truncated Gamma';
    mu_mid = rand()*5 + 5;
    mu_top = rand()*5 + 5;
    MU = gaminv(uu, mu_mid,mu_top );
    MU( MU > 4* mean_mu ) = [];
    pdf_mu = @(x) gampdf(x,mu_mid,mu_top);
    
    
    % chi squared
elseif distribution_nr == 6
    dist_name = 'Truncated Chi quared';
    mean_mu = rand()*10 + 100;
    MU = chi2inv(uu, mean_mu);
    MU( MU > quantile(MU, 0.95) ) = [];
    pdf_mu = @(x) chi2pdf(x, mean_mu);
    
    
    
    
    % truncated lognormal
elseif distribution_nr==7
    dist_name = 'Truncated Lognormal';
    log_mean_mu = log( mean_mu*2 );
    log_sd_mu = log( std_mu/20 );
    MU = logninv(uu, log_mean_mu, log_sd_mu);
    pdf_mu = @(x) lognpdf(x, log_mean_mu, log_sd_mu);
    
    MU( MU > quantile(MU, 0.99) ) = [];
    
    
    
elseif distribution_nr==8
    dist_name = 'Mix of 3 Gaussians';
    K = nr_indivs;
    uu = linspace(1/K, 1-1/K, K);
    std_mu = 8;
    mu1 = norminv(uu, 50, std_mu);
    mu2 = norminv(uu, 100, std_mu);
    mu3 = norminv(uu, 150, std_mu);
    MU = sort([mu1, mu2, mu3]);
    pdf_mu= NaN;
    
    
    
elseif distribution_nr==9
    % triple peaked distribution
    weight_on_bumps = 0.3;
    [dist_name, MU, pdf_mu] = gen_mu_3peaks(uu, muH, muL, weight_on_bumps );
    
elseif distribution_nr == 10
    % double peaked distribution
    dist_name = '2 Peaks (not log-concave)';
    weight_on_bumps = 5;
    K = nr_indivs;
    d_mu = muH - muL;
    mu1 = muL + d_mu *(1/3);
    mu2 = muL + d_mu * (2/3);
    
    width = d_mu * (1/40);
    MU = linspace(muL, muH, K);
    MU_extra1 = linspace(mu1-width, mu1+width, weight_on_bumps*K);
    MU_extra2 = linspace(mu2-width, mu2+width, weight_on_bumps*K);
    
    % MU_extra3 = linspace(muH-width, muH+width, weight_on_bumps*K);
    MU_extra3 = [];
    
    MU = [MU, MU_extra1, MU_extra2, MU_extra3 ];
    MU = sort(MU);
    pdf_mu = NaN;
    
elseif distribution_nr == 11
    dist_name = 'Linear Increasing';
    pdf_mu = NaN;
    
    % inv CDF is sqrt(F *muH^2);
    uu = linspace(small_nr, 1-small_nr, nr_indivs);
    MU = sqrt( uu * muH^2);
    
elseif distribution_nr == 12
    dist_name = 'Linear Decreasing';
    pdf_mu = NaN;
    
    % inv CDF is 1 - 2*muH*sqrt(1+F);
    uu = linspace(small_nr, 1-small_nr, nr_indivs);
    MU = muH*(1 - sqrt(1-uu));
    
elseif distribution_nr == 13
    dist_name = 'Gaussian + Exponential';
    K = nr_indivs;
    uu = linspace(1/K, 1-1/K, K);
    
    std_mu = 20;
    mean_mu = 100;
    mu1 = norminv(uu, mean_mu, std_mu);
    mu1(mu1<0) = [];
    
    lambda = 20;
    mu2 = expinv(uu, lambda);
    
    MU = sort([mu1, mu2]);
    pdf_mu= NaN;
    
elseif distribution_nr==14
    % triangular distirbution
    mu_mid = 50;
    area1 = 0.9;
    [dist_name, MU, pdf_mu] = gen_mu_triangular(uu, mu_mid, area1 );
    
    
    
elseif distribution_nr == 15
    lambda = 10;
    [dist_name, MU, pdf_mu] = gen_mu_reverse_exponential(uu, lambda);  
    MU( MU < quantile(MU, 0.01) ) = [];
    
    
elseif distribution_nr == 16
    weight_on_horn = 1;
    [dist_name, MU, pdf_mu] = gen_mu_left_horn(uu, muH, muL, weight_on_horn);
    
    
    
elseif distribution_nr == 17
    weight_on_horn = 1;
    [dist_name, MU, pdf_mu] = gen_mu_right_horn(uu, muH, muL, weight_on_horn);
    
    
 elseif distribution_nr == 18
     weight_on_horn = 2;
    [dist_name, mu1, pdf_mu] = gen_mu_right_horn(uu, muH, muL, weight_on_horn);   
    [dist_name, mu2, pdf_mu] = gen_mu_left_horn(uu, muH, muL, weight_on_horn);
    dist_name = 'Double Peaked at Extremes';
    MU = sort([mu1,mu2]);
    
    
elseif distribution_nr == 19
    dist_name = 'Reverse Exponential + High-Cost Mass (not log-concave)';
    lambda = 10;
    [~, mu1, pdf_mu] = gen_mu_reverse_exponential(uu, lambda);
    
    max_mu = max(mu1);
    mu2 = linspace(max_mu, max_mu*1.2,  6*nr_indivs);
    MU = sort([mu1, mu2]);
    
elseif distribution_nr == 20
    
    nr_reps = 5;
    
    K = round(nr_indivs/(nr_reps+1));
    small_nr = 1/(K+1);
    uu = linspace(small_nr, 1-small_nr, K);
    
    lambda = 5;
    [~ , mu1, pdf_mu] = gen_mu_reverse_exponential(uu, lambda);
    dist_name = 'Reverse Exponential + Uniform (log-concave)';
    nr_indivs = numel(mu1);
    max_mu = max(mu1);
    
    % nr of times that a mass of uniform that's the same as the exponential
    % mass gets added
    ub1 = lambda*nr_reps + max_mu;
    mu2 = linspace(max_mu, ub1,  nr_reps*nr_indivs);
    
    MU = sort([mu1, mu2 ]);
    
    
else
    error('no such distribution possible');
end


make_graph = 0;
if make_graph==1
    clf; histogram(MU, nr_layers);
    title('generated types')
    xlabel('\mu')
    pause(1)
    
end


%% checks on outputs

if any(MU<0); error('should have MU>=0'); end


end


%%




%%



function [dist_name, MU, pdf_mu] = gen_mu_reverse_exponential(uu, lambda)

%     lambda = 1;
    [~, MU, pdf_mu] = gen_mu_exponential(uu, lambda );
    dist_name = 'Reverse Exponential';
    MU = sort(-MU + max(abs(MU)));   
    
end



function [dist_name, MU, pdf_mu] = gen_mu_left_horn(uu, muH, muL, weight_on_horn)
    nr_indivs = numel(uu);
    dist_name = 'Mass Point at Low Cost';
    mu1 = linspace(muL, muH, nr_indivs);
    mu_mid = muL + (2/15)*(muH-muL);
    nr_indivs_on_horn = round(weight_on_horn*nr_indivs);
    mu2 = linspace(muL, mu_mid, nr_indivs_on_horn);
    pdf_mu = NaN;
    MU = sort([mu1, mu2]);
end


function [dist_name, MU, pdf_mu] = gen_mu_right_horn(uu, muH, muL, weight_on_horn)
    
    nr_indivs = numel(uu);
    dist_name = 'Mass Point at High Cost';
    mu1 = linspace(muL, muH, nr_indivs);
    mu_mid = muH - (2/15)*(muH-muL);
    nr_indivs_on_horn = round(weight_on_horn*nr_indivs);
    mu2 = linspace(mu_mid, muH, nr_indivs_on_horn);
    pdf_mu = NaN;
    MU = sort([mu1, mu2]);
    
    
end

function [dist_name, MU, pdf_mu] = gen_mu_3peaks(uu, muH, muL, weight_on_bumps )

    dist_name = '3 Peaks (not log-concave)';
    mu_mid = (muH+muL)/2;
    
    K = numel(uu);
    nr_indivs_bumps = round(K*weight_on_bumps);
    MU = linspace(muL, muH,  K);
    MU_extra1 = linspace(muL, muL+10, nr_indivs_bumps);
    MU_extra2 = linspace(muH-10, muH, nr_indivs_bumps);
    MU_extra3 = linspace(mu_mid-5, mu_mid+5, nr_indivs_bumps);
    MU = [MU, MU_extra1, MU_extra2, MU_extra3];
    MU = sort(MU);
    pdf_mu = NaN;
    
end





function [dist_name, MU, pdf_mu] = gen_mu_triangular(uu, mu_mid, area1 )

% [dist_name, MU, pdf_mu] = gen_mu_triangular(uu, mu_mid, area1 )
% mu_mid: value of mu at which the density becomes downward sloping
% area1: area under the increasing density (ie, in the first part of the distribution)

nr_indivs = numel(uu);

dist_name = 'Triangular';
pdf_mu = NaN;

% increasing part
h_at_mid = area1*2/mu_mid;  % density height at the point of inflexion
[ mu1 ] = gen_mu(0, mu_mid, nr_indivs, 11);

% decreasing part
% the top value of mu adjusts so that there is equal mass on either side
mu_top = 2/h_at_mid;
nr_indivs_part2 = round( nr_indivs*( 1-area1)/area1 );
[ mu2 ] = gen_mu(0, mu_top-mu_mid, nr_indivs_part2, 12) + mu_mid;
MU = sort([mu1, mu2]);

end



function [dist_name, MU, pdf_mu] = gen_mu_exponential(uu, lambda )

dist_name = 'Truncated Exponential';
MU = expinv(uu, lambda);
pdf_mu = @(x) exppdf(x, mean_mu);

end
