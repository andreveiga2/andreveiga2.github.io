%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%% Project: Optimal Contract Regulation in Selection Markets
%%%%% Authors: Yehuda "John" Levy, Andre Veiga
%%%%% Created: June 3, 2024
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%



%% setup

rng(1); % set the seed each time
clear;
beep on
warning('off','all');
addpath('lib/','-begin');

% path where stuff is saved
output_path = '../output/';

% Check if the folder exists
if exist(output_path, 'dir')
    % Delete all files in the directory
    delete(fullfile(output_path, '*'));
else
    % If the folder does not exist, create it
    mkdir(output_path);
end

% set interpreter to latex (for graph titles, etc)
set(0,'defaultTextInterpreter','latex');






%% baseline specs

% number of individuals to simulate
% nr of x points to check when solving for equilibrium
[nr_indiv_base, nr_x_base] = deal(2010, 1e3);

% type space parameters
[muH, muL, v] = deal(150, 20, 25);
MU = linspace(muL, muH, nr_indiv_base);





%% Figure 6 

% this code produces graph of Figure 6, which shows the minimum value of
% the minimum coverage, as a function of rho, such that increases in the
% non-buyer fee increase welfare

J = 20;
RHOS = linspace(1.0001, 6, J);
[ x_min ] = deal(NaN(J,1));

for i=1:J
    rho_i = RHOS(i);
    delta_i = delta_direct(rho_i);
    x_min(i) = 1-sqrt(delta_i);
end

[rows,cols,pp] = deal(1,1,0); clf

pp=pp+1; subplot(rows,cols,pp)
plot(RHOS, x_min, '-o')
xlabel('$\rho$')
title('$\underline{x}^{min}$')

mysave( gcf, output_path, 'x_min', [rows,cols]);



%% graphs illustrating equilibria

% draw equilibria examples for each type of market (ie, voluntary,
% mandatory, akerlof, assuming T=0
draw_eql_egs( output_path )


%% graphs of effect of parameters on welfare

% look at how the regulatory parameters affect welfare for various distributions
welf_vs_param( output_path, 'xL_akerlof' )
welf_vs_param( output_path, 'xH' )
welf_vs_param( output_path, 'xL' )
welf_vs_param( output_path, 'T' )
welf_vs_param( output_path, 'xL_mandat' )



beep











%%
















%% aux functions for compute Rho

function [DELTA1, DELTA2] = delta_direct(rho)

assert( all(rho>1))

sqrt_root_term = sqrt( ((-1+rho).^2).* rho );
denom = (rho-1).^2;

z1 = - (rho.*(1-rho) + sqrt_root_term) ./ denom;
inside1 = fn_to_max(z1,rho);
DELTA1 = 2*(1./inside1) - 1;

z2 = (rho-1).*rho + sqrt_root_term ./ denom;
inside2 = fn_to_max(z2,rho);
DELTA2 = 2*(1./inside2) - 1;

end







function [y] = fn_to_max(z,rho)

assert( all(rho>1))
assert( all( 0<=z) )
% assert( all( z<=1) )

numerator = z.^2 + rho.*(1-z.^2);
denominator = z + rho.*(1-z);
y = numerator ./ denominator;

end















