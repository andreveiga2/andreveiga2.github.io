function [ varargout ] = make_col_vec( input )

% turns vectors or matrices into column vectors
% can take multiple inputs
% output has same numel as input

% if there is a single input
if nargin==1
    if size(input,2)==1
        % if it's already a col vec, output = input
        varargout{1} = input;
    else
        varargout{1} = reshape( input ,[], 1);
    end
    
    
else
    % if there are multiple inputs
    % not sure if this bottom part works well or not
    for i=1:numel(input)
        x = input{i};
        x = reshape(x,[],1);
        varargout(i) = {x};
    end
    
end

end

