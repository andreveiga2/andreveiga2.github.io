function [] = make_eql_graph(X_VAR, MU_STAR_UP, MU_STAR_DOWN, MU, X_STAR, WELF_TOT,  title_text, x_label_text, output_path, file_name_k, opts, sg_title)




set(gca,'TickLabelInterpreter','latex')
set(groot,'defaulttextinterpreter','latex');  
set(groot, 'defaultAxesTickLabelInterpreter','latex');  
set(groot, 'defaultLegendInterpreter','latex');



% process inputs
partial_only = 0;
is_akerlof = 0;
if isequal(opts, 'partial only')
    partial_only = 1;
elseif isequal(opts, 'akerlof')
    is_akerlof = 1;
end

X_VAR = make_col_vec(X_VAR);
MU_STAR_UP = make_col_vec(MU_STAR_UP);
MU_STAR_DOWN = make_col_vec(MU_STAR_DOWN);

% makes graph of mu*, x*, welfare and plots histogram of types
muH = max(MU);
muL = min(MU);


% check on inputs
assert( isequal( size(MU_STAR_UP), size(MU_STAR_DOWN) ))

if any(isnan(MU_STAR_UP))==0
    assert( max(MU_STAR_UP) <= muH )
    assert( min(MU_STAR_UP) >= muL )
    
end

if any(isnan(MU_STAR_DOWN))==0
    assert( max(MU_STAR_DOWN) <= muH )
    assert( min(MU_STAR_DOWN) >= muL )
end


% set number of subplots
nr_cols = 4;
if is_akerlof==1; nr_cols=nr_cols-1; end
[rows, cols, pp] = deal(1, nr_cols, 0); clf


% histogram is type distribution
pp=pp+1; subplot(rows,cols, pp)
nr_bins = 15;
bin_edges = linspace(min(MU), max(MU), nr_bins+1);
histogram(MU, bin_edges)
title('histogram $\mu$')
xlabel('$\mu$')
ylabel('PDF')



% define full pooling and partial pooling
cond_full_pool = MU_STAR_UP==muH ;
cond_partial_pool = MU_STAR_UP<muH & MU_STAR_UP>muL;
cond_zero_pool = MU_STAR_UP==muL;


if is_akerlof
    cond_full_pool = true(size(MU_STAR_UP));
    cond_partial_pool = false(size(MU_STAR_UP));
end


% define x and mu* conditional on this
x_partial = X_VAR( cond_partial_pool );
mu_star_up_partial = MU_STAR_UP( cond_partial_pool );
mu_star_down_partial = MU_STAR_DOWN( cond_partial_pool );
x_star_partial = X_STAR( cond_partial_pool );
w_partial = WELF_TOT( cond_partial_pool );


x_full = X_VAR( cond_full_pool );
mu_star_up_full = MU_STAR_UP( cond_full_pool );
mu_star_down_full = MU_STAR_DOWN( cond_full_pool );
x_star_full = X_STAR( cond_full_pool );
w_full = WELF_TOT( cond_full_pool );


x_zero = X_VAR( cond_zero_pool );
mu_star_up_zero = MU_STAR_UP( cond_zero_pool );
mu_star_down_zero = MU_STAR_DOWN( cond_zero_pool );
x_star_zero = X_STAR( cond_zero_pool );
w_zero = WELF_TOT( cond_zero_pool );




% graph of mu*
pp=pp+1; subplot(rows,cols, pp)

legend_text = {};

legend_text = add_plot(x_partial, mu_star_up_partial, legend_text, '$\mu*$ Partial Pooling', 'partial');
legend_text = add_plot(x_partial, mu_star_down_partial, legend_text, '$\mu_*$ Partial Pooling', 'partial');

if partial_only == 0
    legend_text = add_plot(x_full, mu_star_up_full, legend_text, '$\mu*$ Full Pooling', 'full');
    legend_text = add_plot(x_full, mu_star_down_full, legend_text, '$\mu_*$ Full Pooling', 'full');
    
    legend_text = add_plot(x_zero, mu_star_up_zero, legend_text, '$\mu*$ Zero Pooling', 'zero');
    legend_text = add_plot(x_zero, mu_star_down_zero, legend_text, '$\mu_*$ Zero Pooling', 'zero');
end

xlabel( x_label_text, 'interpreter','latex' )
title( title_text)
legend(legend_text,  'Location', 'Best','AutoUpdate','off')
yline(muH, '--k')
yline(muL, '--k')







% don't do the graph for x* in the Akerlof setting (just 2 contracts)
if 1==1
    if is_akerlof==0
        pp=pp+1; subplot(rows,cols, pp)
        legend_text = {};
        
        legend_text = add_plot(x_partial, x_star_partial, legend_text, 'Partial Pooling', 'partial');
        
        if partial_only == 0
            legend_text = add_plot(x_full, x_star_full, legend_text, 'Full Pooling', 'full');
            legend_text = add_plot(x_zero, x_star_zero, legend_text, 'Zero Pooling', 'zero');
        end
        
        title('x*')
        xlabel( x_label_text ,'interpreter', 'latex')
        legend(legend_text,  'Location', 'Best', 'AutoUpdate','off')
    end
end











% plot welfare
pp=pp+1; subplot(rows,cols, pp)
legend_text = {};

legend_text = add_plot(x_partial, w_partial, legend_text, 'Partial Pooling', 'partial');

if partial_only == 0
    legend_text = add_plot(x_full, w_full, legend_text, 'Full Pooling', 'full');
    legend_text = add_plot(x_zero, w_zero, legend_text, 'Zero Pooling', 'zero');
end

title('Welfare')
xlabel( x_label_text ,'interpreter','latex')
legend(legend_text,  'Location', 'Best', 'AutoUpdate','off')







% print a message to console if welfare or x* is non monotonic
if numel(w_partial)>0
    if min( diff(w_partial) ) * max( diff(w_partial) ) < 0
        fprintf('!!!! w_partial non monotonic !!!!\n')
    end
end

if numel(x_partial)>0
    if min( diff(x_partial) ) * max( diff(x_partial) ) < 0
        fprintf('!!! x_partial non monotonic !!!!\n')
    end
end









if 1==0
    
    %     cumulative mean of MU
    pp=pp+1; subplot(rows,cols, pp)
    cum_mean_mu = cummean(MU);
    plot(MU, cum_mean_mu)
    
    %     change in welfare
    pp=pp+1; subplot(rows,cols, pp)
    plot(X_VAR(2:end), diff(WELF_TOT), '-o')
    title('\Delta Welfare')
    xlabel( x_label_text )
    
    
    
    % graph phi(x) = mu* - E[mu | mu<mu*] > 0
    nr_mu_vals = numel(MU);
    phi = NaN(nr_mu_vals);
    for i=1:nr_mu_vals
        mu_i = MU(i);
        phi(i) = mu_i - mean( MU(MU<mu_i) );
    end
    pp=pp+1; subplot(rows,cols, pp)
    plot(MU, phi, '-o')
    title([ '\phi(\mu)' ])
    xlabel( '\mu' )
    
    
    pp=pp+1; subplot(rows,cols, pp)
    plot(X_VAR, GH, '-o'); hold on
    plot(X_VAR, GL, '-x'); hold on
    legend('E[g(\sigma) | \mu>\mu* ]', 'g(xL)', 'Location', 'Best')
    xlabel( x_label_text )
    title('g(x)')
    
    
    pp=pp+1; subplot(rows,cols, pp)
    plot(X_VAR, WH, '-x'); hold on
    plot(X_VAR, WM, '-o'); hold on
    plot(X_VAR, WL, '-x'); hold on
    legend('W_H (\mu>\mu*)', 'W_M (\mu*>\mu>\mu_*)', 'W_L (\mu<\mu_*)', 'Location', 'Best')
    xlabel( x_label_text )
    title(['welf at top, mid, bottom'])
    
    
    pp=pp+1; subplot(rows,cols, pp)
    plot(X_VAR, MIN_VAL, '-o')
    title('convergence (small=good)')
    xlabel( x_label_text )
end


sgtitle(  sg_title )


mysave(gcf, output_path, file_name_k, 1.1*[rows,cols])

end






function [legend_text] = add_plot(x, y, legend_text, legend_text_add, which_part)

color_zero = [0 0.4470 0.7410];
color_partial = [0.8500 0.3250 0.0980];
color_full = [0.9290 0.6940 0.1250];

if isequal(which_part, 'zero')
    color_here = color_zero;
    plot_style = '-o';
elseif isequal(which_part, 'partial')
    color_here = color_partial;
    plot_style = '-d';
elseif isequal(which_part, 'full')
    color_here = color_full;
    plot_style = '-x';
else
   error('no such option') 
end

    if all(isnan(y))==0 && numel(y)>0
        plot(x, y, plot_style ); hold on
        legend_text{end+1} = legend_text_add;
    end

end
