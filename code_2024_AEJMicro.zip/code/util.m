function [y] = util(mu, v, x, p)
    % certainty equivalent for CARA-Gaussian preferences
    y = x.*mu + g(x).*v - p;
end
