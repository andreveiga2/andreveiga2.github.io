function [ w_tot  ] = welf(xH, xL, v, mu_star_up, mu_star_down, MU)

% [ w_tot  ] = welf(xH, xL, v, mu_star_up, mu_star_down, MU)
% computes welfare given the chracteristics of equilibrium mu_star_up,
% mu_star_down, x_star


if any( isnan([ mu_star_up, mu_star_down] ))
    [ w_tot ]  = deal(NaN);
    disp('welf: input NaN, output NaN')
    return 
end


method = 1; 
if method==1
    [ w_tot  ] = welf_method1(xH, xL, v, mu_star_up, mu_star_down, MU);
end

end














%% method 1

function [ w_tot ] = welf_method1(xH, xL, v, mu_star_up, mu_star_down, MU)

% [ w_tot ] = welf_method1(xH, xL, v, mu_star_up, mu_star_down, MU)
% computes welfare 
% puts equal weight on each type in the vector MU, so these types should be
% generated according to the probability distribution of types
% make sure no individual is counted twice

nr_indivs = numel(MU);

% mu in [mu*,muH]
MUS_UP = MU( MU>=mu_star_up);
X_UP = find_sigma(xH, v, MUS_UP);
wH_sum = sum(g(X_UP));

% mu in [mu_*, mu*]
MUS_MID = MU( MU<mu_star_up & MU>=mu_star_down );
wM_sum = g(xL)*numel(MUS_MID);

% mu in [muL, mu_*]
wL_sum = 0 ;

% sum all the componenets of welfare and compute the mean (so it does not
% vary greatly with the number of simulated types)
w_tot = (wH_sum + wM_sum + wL_sum)/nr_indivs;

end










