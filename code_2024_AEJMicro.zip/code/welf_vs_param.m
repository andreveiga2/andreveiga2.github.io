function [] = welf_vs_param( output_path, param_name)




all_dist = [ 1:20 ];   % all distributions
all_logconc_dist = [1:6, 11, 12, 14:17, 20 ];  % all log-concave distributions

if isequal(param_name,'T')

    % dist 11: W increases with T, but PDF not decreasing
    distributions = [11];
    run_welf_vs_param(output_path, distributions, 'W_disp_T_up1', param_name, 'disp', 50)

    % uniform
    distributions = [1];
    run_welf_vs_param(output_path, distributions, 'W_disp_T_up2', param_name, 'disp', 50)

    % dist 17: W decreasing in T
    distributions = [ 17 ];
    run_welf_vs_param(output_path, distributions, 'W_disp_T_down', param_name, 'disp', [])

    % all distributions
    % run_welf_vs_param(output_path, all_logconc_dist, 'W_disp_T_ALL', param_name, [], [])

elseif isequal(param_name,'xH')

    % dist 2: welfare increases with xH
    dist_here = 2;
    run_welf_vs_param(output_path, dist_here, 'W_disp_xH_up', param_name, 'disp', [])

    % all distributions, just for the record
    % run_welf_vs_param(output_path, all_logconc_dist, 'W_disp_xH_ALL', param_name, 'disp', [])

elseif isequal(param_name,'xL')

    % dist 2: W increases with xL
    dist_here = [2];
    run_welf_vs_param(output_path, dist_here, 'W_disp_xL_up', param_name, 'disp', 100)

    % dist 3: W decreases with xL
    dist_here = [3];
    run_welf_vs_param(output_path, dist_here, 'W_disp_xL_down', param_name, 'disp', 150)

    % all distributions, just for the record
    % run_welf_vs_param(output_path, all_logconc_dist, 'W_disp_xL_ALL', param_name, 'disp', 100)


elseif isequal(param_name,'xL_mandat')

    % mandatory purchases: W increases with xL
    dist_W_up = [1,2,3,4,6];
    for i=1:numel(dist_W_up)
        dist_here = dist_W_up(i);
        file_name_i = strcat('W_PPPP_xL_up', num2str(i));
        run_welf_vs_param(output_path, dist_here, file_name_i, param_name, 'mandat', 200)
    end

    % dist 17: W decreases
    dist_here = [17];
    run_welf_vs_param(output_path, dist_here, 'W_PPPP_xL_down', param_name, 'mandat', 100)

    % all distributions (not just log-concave), just for the record
    % run_welf_vs_param(output_path, all_logconc_dist, 'W_PPPP_xL_ALL', param_name, 'mandat', 100)

elseif isequal(param_name,'xL_akerlof')

    dist_here = [1];
    run_welf_vs_param(output_path, dist_here, 'Akerlof_xL', param_name, 'mandat', 100)


else
    error('no such parameter')
end

end









%%





%%



function [] = run_welf_vs_param(output_path, distributions, file_name, param_name, subset_eql, nr_param_values)


% type space parameters
[muH, muL, v] = deal(150, 20, 25);

% process everything first and then make all the graphs, because some
% graphs are automatically made during the computation of equilibrium
[xL0, xH0, T0 ] = deal(0.1, 0.95, 0);

small_nr_x = 0.01; % start the range of contracts just above the bottom and end just below the top
XL_min = xL0 + small_nr_x;
XH_max = xH0 - small_nr_x;
nr_x = 1e3;

% use this to check that welfare is increasing when eql goes from disp to PPPP
% [xL0, xH0, T0 ] = deal(0, 0.95, 0);
% XL_min = 0;
% XH_max = 0.1;

if isequal(nr_param_values, [])
    nr_param_values = 30;
end


nr_distributions = numel(distributions);
nr_indiv_base = 2010;
[ W_TOT, MUS_UP, MUS_DOWN ] = deal( NaN(nr_param_values, nr_distributions) );
% w_tot_no_zero = NaN(nr_distributions,1);
[BIG_MU, DIST_NAMES, param_vals ] = deal( cell(nr_distributions) );

% first loop over distributions of types; for each distribution compute
% equilibrium for different values of the parameter
for j=1:nr_distributions
    distr_j = distributions(j);
    [ MU, ~, dist_name] = gen_mu( muL, muH, nr_indiv_base, distr_j );
    BIG_MU{j} = MU;
    DIST_NAMES{j} = dist_name;

    % generate range of the correct variable within each case. It's a big
    % inefficient but makes the code more readable
    for i=1:nr_param_values

        if isequal(param_name,'T')
            values_param = linspace(0, max(MU)/8, nr_param_values);
            xL0_w_T = 0.2;    % if xL is too close to zero, nobody buys x=0, so T does nothing
            [ MUS_UP(i,j), MUS_DOWN(i,j), ~, W_TOT(i,j)] = find_eql_with_zero(xH0, xL0_w_T, v, MU, nr_x, values_param(i));
            param_name_tex = '$T$';

        elseif isequal(param_name,'xH')
            values_param = linspace( XL_min, XH_max, nr_param_values);
            [ MUS_UP(i,j), MUS_DOWN(i,j), ~, W_TOT(i,j)] = find_eql_with_zero(values_param(i), xL0, v, MU, nr_x, T0);
            param_name_tex = '$\overline{x}$';


        elseif isequal(param_name,'xL')
            values_param = linspace( XL_min, XH_max, nr_param_values);
            [ MUS_UP(i,j), MUS_DOWN(i,j), ~, W_TOT(i,j)] = find_eql_with_zero(xH0, values_param(i), v, MU, nr_x, T0);
            param_name_tex = '$\underline{x}$';

        elseif isequal(param_name,'xL_mandat')
            xL0 = 0.001;
            XL_min = xL0 + small_nr_x;
            values_param = linspace( XL_min, XH_max, nr_param_values);
            [ MUS_UP(i,j), MUS_DOWN(i,j), ~, W_TOT(i,j)] = find_eql_nozero(xH0, values_param(i), v, MU, nr_x );
            param_name_tex = '$\underline{x}$';

        elseif isequal(param_name,'xL_akerlof')
            xL0 = 0.001;
            XL_min = xL0 + small_nr_x;
            values_param = linspace( XL_min, XH_max, nr_param_values);
            [ MUS_UP(i,j), MUS_DOWN(i,j), ~, W_TOT(i,j), ~] = find_eql_akerlof(values_param(i), v, MU, T0);
            param_name_tex = '$\underline{x}$';

        else
            error('no such parameter')
        end

        % if graphing only dispersive equilibria, remove points where
        % either mu*=muH or mu_*=muL
        if isequal(subset_eql, 'disp')
            if MUS_UP(i,j)==max(MU) || MUS_DOWN(i,j)==min(MU) || isnan(MUS_DOWN(i,j))
                [ MUS_UP(i,j), MUS_DOWN(i,j), W_TOT(i,j)] = deal(NaN);
            end

        elseif isequal(subset_eql, 'mandat')
            % graphing equilibria with mandatory purchase.
            % removes all the points for which mu*=muH, because for those
            % point equilibrium is lemons
            if MUS_UP(i,j)==max(MU)
                [ MUS_UP(i,j), MUS_DOWN(i,j), W_TOT(i,j)] = deal(NaN);
            end

        elseif isequal(subset_eql, 'boundary_PPP')
            % in a mandatory setting (hence the focus on MUS_UP), keep
            % only the points when there is partial pooling
            if MUS_UP(i,j)==min(MU)
                [ MUS_UP(i,j), MUS_DOWN(i,j), W_TOT(i,j)] = deal(NaN);
            end

        end

    end

    param_vals{j} = values_param;

end




[rows,cols,pp] = deal(nr_distributions, 3, 0); clf

for j=1:nr_distributions


    MU_j = BIG_MU{j};
    muH = max(MU_j);
    muL = min(MU_j);

    % histogram of types
    pp=pp+1; subplot(rows,cols, pp)
    nr_bins = 15;
    bin_edges = linspace(min(MU_j), max(MU_j), nr_bins+1);
    histogram(MU_j, bin_edges )
    title( DIST_NAMES{j} )
    xlabel('$\mu$')


    % path of mu* and mu_*
    MUS_UP_here = MUS_UP(:,j);
    params_j = param_vals{j};
    full_pool = MUS_UP_here ==max(MU_j);
    pp=pp+1; subplot(rows,cols,pp); hold on;
    plot(params_j(full_pool), MUS_UP(full_pool,j), '-o')
    plot(params_j(~full_pool), MUS_UP(~full_pool,j), '-s')
    plot(params_j(full_pool), MUS_DOWN(full_pool,j), '-d')
    plot(params_j(~full_pool), MUS_DOWN(~full_pool,j), '-x')


    if all(isnan(MUS_DOWN))
        title('$\mu^*$')
    elseif all(isnan(MUS_UP))
        title('$\mu_*$')
    else
        title('$\mu^*, \mu_*$')
    end

    xlabel(param_name_tex)
    yline([muH, muL])
    mu_min_graph = max(muL*0.9, 0);
    ylim([mu_min_graph, muH*1.1])

    % welfare
    welf_extra_text = '';
    pp=pp+1; subplot(rows,cols,pp); hold on;
    plot(params_j(full_pool), W_TOT(full_pool,j), '-o')
    plot(params_j(~full_pool), W_TOT(~full_pool,j), '-s')
    diff(W_TOT(:,j))
    if all( diff(W_TOT(:,j))>=0); welf_extra_text = '(increasing)'; end
    title(['Welfare ' welf_extra_text])
    xlabel(param_name_tex)

    pause(0.1)

end

mysave(gcf, output_path, file_name, 1*[rows,cols])


end


