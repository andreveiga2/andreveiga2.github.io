%%
%--------------------------------------------------------------------------
% main.m
%--------------------------------------------------------------------------
% Original program by EJL (2012)
% Adaptation by J. Mountjoy and Andre Veiga (2015)
% for "Product Design in Selection Markets" by
% Andre Veiga and E. Glen Weyl 
%--------------------------------------------------------------------------
% Solves the optimal down and repayment problem for simulated borrowers.
%
% Plots marginal consumers for an increase in minimum down payment and
% an increase in car price. 
%
% Generates data on default rates for marginal and average consumers for
% a wide range of car prices and minimum down payments
%
% Plots default rates for marginal consumers.
%--------------------------------------------------------------------------


%--------------------------------------------------------------------------
% variable declarations
%--------------------------------------------------------------------------
clear;


% parameters
global B T G Nsim mindwn ptilda dscale pscale deltaD deltaP APRUSE TERM;
global rho psi cval delta beta betap rra theta;
global saleeps downeps epsilon up ud;
global ystep ymax ymin ystates ynum y;
global lstep lmax lmin lstates lnum l;
global vstep vmax vmin vstates vnum v;


%--------------------------------------------------------------------------
% define discretized state space
%--------------------------------------------------------------------------
ymin=0.050; ystep=0.050; ymax=10.00; 
ystates=(ymin:ystep:ymax); ynum=size(ystates,2); % income states

lmin=0.100; lstep=0.100; lmax=2.000; 
lstates=(lmin:lstep:lmax); lnum=size(lstates,2); % monthly payment states (should be m in EJL notation)

vmin=-3.00; vstep=0.600; vmax=6.000; 
vstates=(vmin:vstep:vmax); vnum=size(vstates,2); % car valuation states


%--------------------------------------------------------------------------
% define parameters
%--------------------------------------------------------------------------
T = 40; G = T; B = 20; 
dscale=5; pscale=20; 
deltaD=0.100*dscale;  %Counterfactual for minimum down payment
deltaP=0.100*pscale;  %Counterfactual for car price

% offer terms from the sample
mindwn=1.000;       % sample average min. down (rounded, thousands)
ptilda=11.000;      % sample average car price (rounded, thousands)
APRUSE=29.9;        % sample mode APR
TERM=42.0;          % sample mode term

% imposed parameter values
delta = 0.880^((TERM/T)/12); 
beta  = 0.750^((TERM/T)/12); 
betap = beta; 
theta = 1.000; 
rra   = 0.999; 
rho   = 1.000; 
cval  = 0.000;
psi   = 0.000;

% calibrated parameter values (calibrated from EJL's proprietary data)
vavg = 2.9309;
vvar = 1.5348;
davg = 0.5012;
dvar = 2.0616;
corr =-0.0247;
sig2 = 0.2954;
phi  = 1.0295;


%--------------------------------------------------------------------------
% consumption utilities (YxLxV)
%--------------------------------------------------------------------------
y = repmat(ystates',[1,lnum,vnum]);
l = repmat(lstates ,[ynum,1,vnum]);
v = ones(1,1,vnum); v(1,1,:)=vstates; v=repmat(v,[ynum,lnum,1]);
up = CalcUtility(y,l);                              % flow utility from having income y and car payment l, i.e. net money (y-l)
ud = CalcUtility(y,0);


%--------------------------------------------------------------------------
% simulate unobservables
%--------------------------------------------------------------------------
Nsim = 1*10^6;                                          % Number of simulated borrowers
stream = RandStream('mt19937ar','Seed',1); RandStream.setGlobalStream(stream); saleeps = randn(Nsim,1); % outside option
stream = RandStream('mt19937ar','Seed',2); RandStream.setGlobalStream(stream); downeps = randn(Nsim,1); % initial liquidity
stream = RandStream('mt19937ar','Seed',3); RandStream.setGlobalStream(stream); epsilon = randn(Nsim,T); % liquidity shocks


%--------------------------------------------------------------------------
% solve borrower's optimal purchase and repayment problem
%--------------------------------------------------------------------------
% simulate outside option (vout) and liquidity (y0,...,yT) variables
% v0: initial car valuation
% vi: initial car valuation grid index (# of steps from bottom of grid)
% y0: initial liquidity (income)
% yi: initial liquidity grid index
% yt: realized income each period (outcome of random walk)
% yindex: grid index for realized income each period
[v0 vi y0 yi yindex yt] = simulate_unobservables(vavg,vvar,davg,dvar,corr,sig2);

% solve repayment problem for all states (note: independent of d,p)
% P: income state transition matrix
% EVP: expected value of making payment
% EVD: expected value of defaulting
[P EVP EVD D] = optimal_repayment(sig2,delta,beta,psi,phi,theta);




%%
%--------------------------------------------------------------------------
% Part I: Plot the consumers who are on the margin of purchasing with 
% respect to increases in minimum down payment and car price.
%--------------------------------------------------------------------------
display('Part I: plot marginal consumers')

mindwn=1;  % measured in thousands 
ptilda=11; % measured in thousands
    
deltaD=0.010; % $10 increase in minimum down 
deltaP=0.5;   % $500 increase in price
fullmindwn=mindwn*1000;
fullptilda=ptilda*1000;
fulldeltaD=deltaD*1000;
fulldeltaP=deltaP*1000;


%--------------------------------------------------------------------------
% calculate optimal outcomes for each borrower, given v0 and y0
%--------------------------------------------------------------------------
% dopt: optimal down payment
% simsale: indicator for purchase
% simxtra: additional down payment made in excess of minimum requirement
% simdef: indicator for default
% simfrac: fraction of payments made

% First, simulate borrower outcomes with baseline mindown and car price
[~, ~, ~, ~, ~, simsale, simless, simxtra, simdef, simfrac] = optimal_down(mindwn,ptilda,v0,vi,y0,yi,yindex,EVP,EVD,D,cval,betap,theta,beta,phi);

% Now increase min down by $10 and resimulate
[~, ~, ~, ~, ~, simsale2, simless2, simxtra2, simdef2, simfrac2] = optimal_down(mindwn+deltaD,ptilda,v0,vi,y0,yi,yindex,EVP,EVD,D,cval,betap,theta,beta,phi);

% Now increase price by $500 and resimulate
[~, ~, ~, ~, ~, simsale3, simless3, simxtra3, simdef3, simfrac3] = optimal_down(mindwn,ptilda+deltaP,v0,vi,y0,yi,yindex,EVP,EVD,D,cval,betap,theta,beta,phi);






%--------------------------------------------------------------------------
% Generate scatterplot
%--------------------------------------------------------------------------

use=y0>-99999;                              % Set boundaries for scatter plots

ii = rand(size(v0)); ii =(ii>.95);           % condition used to graph only 80% of types, for visibility
cond1 = (use & simsale & ~simsale2 & ii);    % condition: those that buy, but don't buy after the increase in min down 
cond2 = (use & simsale & ~simsale3 & ii);    % condition: those that buy, but don't buy after the increase in price 

clf
scatter( y0(cond1), v0(cond1), [], 'b', 'x'); hold on;          % Scatterplot of the marginal consumers when mindown goes up: i.e. simsale==1 & simsale2==0.                                                
scatter( y0(cond2), v0(cond2), [], 'r', '.');                   % Overlay scatterplot of the marginal consumers when price goes up: simsale==1 & simsale3==0.
axis([0 4 0 8]); xlabel('Initial Liquidity ($1000s)'); ylabel('Initial Car Value (utils)');
suptitle(['x-marginals and p-marginals'])
legend( ['x-marginals, x: $' num2str(fullmindwn) '\rightarrow $' num2str(fullmindwn+fulldeltaD)],...
        ['p-marginals, p: $' num2str(fullptilda) '\rightarrow $' num2str(fullptilda+fulldeltaP)]);
set(gcf, 'PaperPosition', [-.2 -.1 5 5]); set(gcf, 'PaperSize', [4.5 4.8]);                      %Position plot at left hand corner with width 5 and height 5.
saveas(gcf,'marginals_1000_mindown_11000_price.pdf');                   % Save scatterplot






%%
%--------------------------------------------------------------------------
% Part II: Loop over a range of mindown and price starting values, and
% save the results in a dataset for analysis and plotting in Stata.
%--------------------------------------------------------------------------
display('Part II: generate data on average and marginal consumers for a wide range of starting values')

results=cell(5,8);      % Pre-allocate cell array for results
i=1; j=1;

for mindwn=0.25:0.25:2  % loop over mindown starting values between $250-$2,000
    
    i=1;
    
    for ptilda=5:3:17   % loop over price starting values between $5,000-$17,000
        
        deltaD=0.010; % Marginals w.r.t. $10 increase in min down
        deltaP=0.5;   % Marginals w.r.t. $500 increase in price
        fullmindwn=mindwn*1000;
        fullptilda=ptilda*1000;
        fulldeltaD=deltaD*1000;
        fulldeltaP=deltaP*1000;
        
        display('Current iteration of mindown and price:')
        [fullmindwn,fullptilda]
        
        %calculate optimal outcomes for each borrower, given vout and y0
        % first with baseline mindown and car price
        [dopt  lopt  uout ubuy  uopt  simsale  simless  simxtra  simdef simfrac] = optimal_down(mindwn,ptilda,v0,vi,y0,yi,yindex,EVP,EVD,D,cval,betap,theta,beta,phi);
        % now increase min down
        [dopt2 lopt2 uout ubuy2 uopt2 simsale2 simless2 simxtra2 simdef2 simfrac2] = optimal_down(mindwn+deltaD,ptilda,v0,vi,y0,yi,yindex,EVP,EVD,D,cval,betap,theta,beta,phi);
        % now increase price
        [dopt3 lopt3 uout ubuy3 uopt3 simsale3 simless3 simxtra3 simdef3 simfrac3] = optimal_down(mindwn,ptilda+deltaP,v0,vi,y0,yi,yindex,EVP,EVD,D,cval,betap,theta,beta,phi);
        
        
        % Calculate mean characteristics for each group of consumers
        colnames = char('marginals_down','marginals_price','average_purchasers');
        rownames = char('','baseline value','increase','number of obs',...
            'initial liquidity','car valuation','pay min down',...
            'extra down','default','uncond pymts made','pymts cond on dflt');
       
        c1 = (simsale & ~simsale2);                 % buy initially, but not after increase in min down
        c2 = (simsale & ~simsale2 & ~simless);      % buy initially, but not after increase in mind down, and put extra down payment
        c3 = (simsale & ~simsale2 & simdef);        % buy initially, but not after increase in mind down, and default
        
        marginals_down = [fullmindwn, ...
            fulldeltaD, ...
            sum( c1 ), ...
            mean([ y0( c1 ), v0( c1 ), simless( c1 )]), ...
            mean(simxtra(c2)), ...
            mean([simdef( c1 ), simfrac( c1 ) ]), ...
            mean(simfrac( c3 )) ]';
        
        c1 = (simsale & ~simsale3);                 % same conditions, but with respect to an increase in price
        c2 = (simsale & ~simsale3 & ~simless);
        c3 = (simsale & ~simsale3 & simdef);
        
        marginals_price = [fullptilda, ...
            fulldeltaP, ...
            sum(c1), ...
            mean([ y0( c1 ), v0( c1 ), simless( c1 )]), ...
            mean(simxtra( c2 )), ...
            mean([ simdef( c1 ), simfrac( c1 ) ]), ...
            mean(simfrac( c3 )) ]';
        
        c1 = (simsale );                        % same conditons, for all buyers
        c2 = (simsale & ~simless);
        c3 = (simsale & simdef);       
        
        average_purchasers = [0, 0, ...
            sum( c1 ), ...
            mean([ y0( c1 ), v0( c1 ), simless( c1 )]), ...
            mean(simxtra( c2 )), ...
            mean([ simdef( c1 ), ...
            simfrac( c1 ) ]), ...
            mean(simfrac( c3 )) ]';
        
        format shortG
        
        stats=cell(11,4);       % pre-allocate cells to be populated
        
        for k=1:11 
            stats{k,1}=rownames(k,:);
        end
        
        for m=2:4
            stats{1,m}=colnames(m-1,:);
        end
        
        for k=2:11
            stats{k,2}=marginals_down(k-1);
            stats{k,3}=marginals_price(k-1);
            stats{k,4}=average_purchasers(k-1);
        end
        
        
        % Save result to master array
        results{i,j}=[marginals_down marginals_price average_purchasers];
        i=i+1;
    
    end
    j=j+1;

end

save('results.mat','results');          % Save results array 




%--------------------------------------------------------------------------
% Export results to CSV spreadsheet
%--------------------------------------------------------------------------

load('results.mat');

k=1;
for j=1:1:8
    for i=1:1:5
        
        mindown(k)=results{i,j}(1,1);
        price(k)=results{i,j}(1,2);
        prdefdown(k)=results{i,j}(8,1);
        prdefprice(k)=results{i,j}(8,2);
        prdefavg(k)=results{i,j}(8,3);
        
        k=k+1;
    end
end

rownames = char('Baseline value ($)','Marginal increase ($)','Number of obs in margin',...
    'Initial liquidity','Car valuation','Pay minimum down','Extra down, if extra',...
    'Probability of default','Uncond. payments made','Payments made, cond. on default');
colnames={'Min down', 'Price', 'Pr(default): down marginals', 'Pr(default): price marginals', ...
    'Pr(default): avg purchaser'};

format shortG;

data = [mindown' price' prdefdown' prdefprice' prdefavg'];

fid = fopen('marginals_and_averages.csv', 'w') ;
fprintf(fid, '%s,', colnames{1,1:end-1}) ;
fprintf(fid, '%s\n', colnames{1,end}) ;
fclose(fid) ;
dlmwrite('marginals_and_averages.csv', data(1:end,:), '-append') ;




%--------------------------------------------------------------------------
% Producing line plot of average default probabilities for each set of
% marginals
%--------------------------------------------------------------------------

c1 = (price'==11000);               % condition for first graph, fixing car price

plot_xmarg = prdefdown(c1)';        % selecting the sub-set of the data where car price = $11000
plot_pmarg = prdefprice(c1)';
plot_average  = prdefavg(c1)';
plot_mindown = mindown(c1)';

clf
plot(plot_mindown, plot_xmarg,'b-x'  , plot_mindown, plot_pmarg,'r-o' , plot_mindown, plot_average,'g-s')
suptitle(['Default Rates by Minimum Down']) 
title(['Car price fixed at p=$11000'])
axis([250 2000 0.4 0.9])
legend('x-marginals','p-marginals','All buyers','Location','Best')
xlabel(['Min Down x ($)']) 
ylabel(['Average Default Rate'])
set(gcf, 'PaperPosition', [-.2 0 6 5]); set(gcf, 'PaperSize', [5.5 5]);                      %Position plot at left hand corner with width 5 and height 5.
saveas(gcf,'default_rates_by_mindown.pdf');



c2 = (mindown'==1000);                  % condition for second graph, fixing mindown

plot_xmarg = prdefdown(c2)';            % selecting the sub-set of the data where mindown=$1000
plot_pmarg = prdefprice(c2)';
plot_average  = prdefavg(c2)';
plot_price = price(c2)';

clf
plot(plot_price, plot_xmarg,'b-x', plot_price, plot_pmarg,'r-o', plot_price, plot_average,'g-s')
suptitle(['Default Rates by Car Price']) 
title(['Mininum down-payment fixed at x=$1000'])
legend('x-marginals','p-marginals','All buyers','Location','Best')
xlabel(['Car Price p ($1000s)']); ylabel(['Average Default Rate']);
axis([5000 17000 0.5 0.9])
set(gcf, 'PaperPosition', [-.2 0 6 5]); set(gcf, 'PaperSize', [5.5 5]);                      %Position plot at left hand corner with width 5 and height 5.
saveas(gcf,'default_rates_by_price.pdf');







%%
%--------------------------------------------------------------------------
% Part III: plot default rates for marginal consumers in modal case using 
% a heat map. Resimulate the model with a larger number of consumers
% to generate a dense scatterplot.
%--------------------------------------------------------------------------
display('Part III: plot default rate heat map for marginals')


%--------------------------------------------------------------------------
% simulate unobservables
%--------------------------------------------------------------------------
Nsim = 5*10^6;              % Number of simulated borrowers (note this is larger than 
                            % above to generate a dense scatterplot for heat map.)
stream = RandStream('mt19937ar','Seed',1); RandStream.setGlobalStream(stream); saleeps = randn(Nsim,1); %outside option
stream = RandStream('mt19937ar','Seed',2); RandStream.setGlobalStream(stream); downeps = randn(Nsim,1); %initial liquidity
stream = RandStream('mt19937ar','Seed',3); RandStream.setGlobalStream(stream); epsilon = randn(Nsim,T); %liquidity shocks


%--------------------------------------------------------------------------
% solve borrower's optimal purchase and repayment problem
%--------------------------------------------------------------------------
% simulate outside option (vout) and liquidity (y0,...,yT) variables
% v0: initial car valuation
% vi: initial car valuation grid index (# of steps from bottom of grid)
% y0: initial liquidity (income)
% yi: initial liquidity grid index
% yt: realized income each period (outcome of random walk)
% yindex: grid index for realized income each period
[v0 vi y0 yi yindex yt] = simulate_unobservables(vavg,vvar,davg,dvar,corr,sig2);

% solve repayment problem for all states (note: independent of d,p)
% P: income state transition matrix
% EVP: expected value of making payment
% EVD: expected value of defaulting
[P EVP EVD D] = optimal_repayment(sig2,delta,beta,psi,phi,theta);


%--------------------------------------------------------------------------
% calculate optimal outcomes for each borrower, given v0 and y
%--------------------------------------------------------------------------
mindwn=1;
ptilda=11;
        
deltaD=0.010; % $10 increase in minimum down (min. down is measured in thousands)
deltaP=0.5;   % $500 increase in price (price is also measured in thousands)
fullmindwn=mindwn*1000;
fullptilda=ptilda*1000;
fulldeltaD=deltaD*1000;
fulldeltaP=deltaP*1000;

% simsale: indicator for purchase
% simdef: indicator for default 

% first, simulate borrower outcomes with baseline mindown and car price
display('Part III,1: simulate baseline')
[~, ~, ~, ~, ~, simsale, ~, ~, simdef, ~] = optimal_down(mindwn,ptilda,v0,vi,y0,yi,yindex,EVP,EVD,D,cval,betap,theta,beta,phi);

% next, increase min down and resimulate
display('Part III,2: simulate increase in min down')
[~, ~, ~, ~, ~, simsale2, ~, ~, simdef2, ~] = optimal_down(mindwn+deltaD,ptilda,v0,vi,y0,yi,yindex,EVP,EVD,D,cval,betap,theta,beta,phi);

% finally, increase price and resimulate
display('Part III,3: simulate increase in price')
[~, ~, ~, ~, ~, simsale3, ~, ~, simdef3, ~] = optimal_down(mindwn,ptilda+deltaP,v0,vi,y0,yi,yindex,EVP,EVD,D,cval,betap,theta,beta,phi);



% Calculate mean default within car value tranches.
% marginal consumers are those who purchase before the
% increases in min down and price, but not after; i.e.
% simsale==1 & (simsale2==0 | simsale3==0). 
meandef_6_00=mean(simdef(v0>=6.00           & simsale & (~simsale2 | ~simsale3)));
meandef_5_75=mean(simdef(v0>=5.75 & v0<6    & simsale & (~simsale2 | ~simsale3)));
meandef_5_50=mean(simdef(v0>=5.50 & v0<5.75 & simsale & (~simsale2 | ~simsale3)));
meandef_5_25=mean(simdef(v0>=5.25 & v0<5.50 & simsale & (~simsale2 | ~simsale3)));
meandef_5_00=mean(simdef(v0>=5.00 & v0<5.25 & simsale & (~simsale2 | ~simsale3)));
meandef_4_75=mean(simdef(v0>=4.75 & v0<5    & simsale & (~simsale2 | ~simsale3)));
meandef_4_50=mean(simdef(v0>=4.50 & v0<4.75 & simsale & (~simsale2 | ~simsale3)));
meandef_4_25=mean(simdef(v0>=4.25 & v0<4.50 & simsale & (~simsale2 | ~simsale3)));
meandef_4_00=mean(simdef(v0>=4.00 & v0<4.25 & simsale & (~simsale2 | ~simsale3)));
meandef_3_75=mean(simdef(v0>=3.75 & v0<4    & simsale & (~simsale2 | ~simsale3)));
meandef_3_50=mean(simdef(v0>=3.50 & v0<3.75 & simsale & (~simsale2 | ~simsale3)));
meandef_3_25=mean(simdef(v0>=3.25 & v0<3.50 & simsale & (~simsale2 | ~simsale3)));
meandef_3_00=mean(simdef(v0>=3.00 & v0<3.25 & simsale & (~simsale2 | ~simsale3)));
meandef_2_75=mean(simdef(v0>=2.75 & v0<3    & simsale & (~simsale2 | ~simsale3)));
meandef_2_50=mean(simdef(v0>=2.50 & v0<2.75 & simsale & (~simsale2 | ~simsale3)));
meandef_2_25=mean(simdef(v0>=2.25 & v0<2.50 & simsale & (~simsale2 | ~simsale3)));
meandef_2_00=mean(simdef(v0>=2.00 & v0<2.25 & simsale & (~simsale2 | ~simsale3)));
meandef_1_75=mean(simdef(v0>=1.75 & v0<2    & simsale & (~simsale2 | ~simsale3)));
meandef_1_50=mean(simdef(v0>=1.50 & v0<1.75 & simsale & (~simsale2 | ~simsale3)));
meandef_1_25=mean(simdef(v0>=1.25 & v0<1.50 & simsale & (~simsale2 | ~simsale3)));
meandef_1_00=mean(simdef(v0>=1.00 & v0<1.25 & simsale & (~simsale2 | ~simsale3)));
meandef_0_75=mean(simdef(v0>=0.75 & v0<1    & simsale & (~simsale2 | ~simsale3)));
meandef_0_50=mean(simdef(v0>=0.50 & v0<0.75 & simsale & (~simsale2 | ~simsale3)));
meandef_0_25=mean(simdef(v0>=0.25 & v0<0.50 & simsale & (~simsale2 | ~simsale3)));
meandef_0_00=mean(simdef(v0>=0.00 & v0<0.25 & simsale & (~simsale2 | ~simsale3)));


% Apply these values to observation-level vector
meandef=ones(Nsim,1);
meandef(v0>=6.00           & simsale & (~simsale2 | ~simsale3))=meandef_6_00;
meandef(v0>=5.75 & v0<6    & simsale & (~simsale2 | ~simsale3))=meandef_5_75;
meandef(v0>=5.50 & v0<5.75 & simsale & (~simsale2 | ~simsale3))=meandef_5_50;
meandef(v0>=5.25 & v0<5.50 & simsale & (~simsale2 | ~simsale3))=meandef_5_25;
meandef(v0>=5.00 & v0<5.25 & simsale & (~simsale2 | ~simsale3))=meandef_5_00;
meandef(v0>=4.75 & v0<5    & simsale & (~simsale2 | ~simsale3))=meandef_4_75;
meandef(v0>=4.50 & v0<4.75 & simsale & (~simsale2 | ~simsale3))=meandef_4_50;
meandef(v0>=4.25 & v0<4.50 & simsale & (~simsale2 | ~simsale3))=meandef_4_25;
meandef(v0>=4.00 & v0<4.25 & simsale & (~simsale2 | ~simsale3))=meandef_4_00;
meandef(v0>=3.75 & v0<4    & simsale & (~simsale2 | ~simsale3))=meandef_3_75;
meandef(v0>=3.50 & v0<3.75 & simsale & (~simsale2 | ~simsale3))=meandef_3_50;
meandef(v0>=3.25 & v0<3.50 & simsale & (~simsale2 | ~simsale3))=meandef_3_25;
meandef(v0>=3.00 & v0<3.25 & simsale & (~simsale2 | ~simsale3))=meandef_3_00;
meandef(v0>=2.75 & v0<3    & simsale & (~simsale2 | ~simsale3))=meandef_2_75;
meandef(v0>=2.50 & v0<2.75 & simsale & (~simsale2 | ~simsale3))=meandef_2_50;
meandef(v0>=2.25 & v0<2.50 & simsale & (~simsale2 | ~simsale3))=meandef_2_25;
meandef(v0>=2.00 & v0<2.25 & simsale & (~simsale2 | ~simsale3))=meandef_2_00;
meandef(v0>=1.75 & v0<2    & simsale & (~simsale2 | ~simsale3))=meandef_1_75;
meandef(v0>=1.50 & v0<1.75 & simsale & (~simsale2 | ~simsale3))=meandef_1_50;
meandef(v0>=1.25 & v0<1.50 & simsale & (~simsale2 | ~simsale3))=meandef_1_25;
meandef(v0>=1.00 & v0<1.25 & simsale & (~simsale2 | ~simsale3))=meandef_1_00;
meandef(v0>=0.75 & v0<1    & simsale & (~simsale2 | ~simsale3))=meandef_0_75;
meandef(v0>=0.50 & v0<0.75 & simsale & (~simsale2 | ~simsale3))=meandef_0_50;
meandef(v0>=0.25 & v0<0.50 & simsale & (~simsale2 | ~simsale3))=meandef_0_25;
meandef(v0>=0.00 & v0<0.25 & simsale & (~simsale2 | ~simsale3))=meandef_0_00;





% increasing bubbles, customized colors
yhi=6; use=y0>-99999;

ii = (mod([1:numel(y0)]',99)==0);                                   % condition used to plot only a subset of consumers
cond = ( use & simsale & (~simsale2 | ~simsale3) & ii);             % condition; being marginal
size = (meandef(cond)/min(meandef(cond))).^10;

% Scatterplot of marginal consumers with default rates via colored heat map
scatter( y0(cond),v0(cond),size,meandef(cond) )
axis([0 4 0 8]);
colormap(flipud(hot));
xlabel('Initial Liquidity ($1000s)');ylabel('Initial Car Value (utils)');
suptitle('Default Probabilities for Marginal Types');
c3=colorbar;
caxis([.2 .9]);
set(get(c3,'ylabel'),'String','Default Rate');
set(gcf, 'PaperPosition', [-.2 -.1 5 5]); set(gcf, 'PaperSize', [4.8 4.8]);                      %Position plot at left hand corner with width 5 and height 5.
saveas(gca,'defaultrate_for_marginals_color.pdf');                                              % Save plot



%--------------------------------------------------------------------------
% end of program
%--------------------------------------------------------------------------
