
clear

%% simulating consumers according to the HHW market

K=100;                                                  % generate K^2 consumers; the final number of consumers will be (K^2)*size_b
[mu, v] = consumers(K);                                 % simulating consumers

%% setup

e=0.2;                                                  % moral hazard elasticity
precision = 100; Kp = precision; Kx = precision;       % number of values of p and x to consider


pmax = 30000; pmin = 0;                                % upper and lower bounds on deviations on p
xmax = 1;   xmin = 0;                                    % upper and lower bounds on deviations on x

contours = [ -0.15 -0.05 0 0.05 0.15];                     % levels of profit to show in the p,x graph
sizeb = 100;                                             % number of replicas of each type to produce in the b in (0,1) space

%% input of LSE values

Input = csvread('MARKETPOWERdata.csv');             % import the data about LSE for different levels of market power (computed in a previous script)
tinput=Input(:,1);
xinput=Input(:,2);
pinput=Input(:,3);
welfinput = Input(:,6);

[M,I] = max(welfinput);                             % select the entry with highest neoclassical welfare

t = tinput(I);                                      % market power, p and x at the welfare maximizing level of market power
p_star = pinput(I);
x_star = xinput(I);

%% defining matrix of profit outcomes to be populated

profit = NaN(Kx, Kp);                   % defining a matrix of values of profit, of dimensions Kp and Kx, where Kp and Kx are the number of gridpoints in the dimennsions p and x

%% loop

pp = linspace(pmin,pmax,Kp)';                           % produce a grid of values of p,x to evaluate profit at
xx = linspace(xmin,xmax,Kx)';

p1_fixed = p_star; x1_fixed = x_star;                   % firm 1 plays the LDPE, we consider deviations by firm 2

pi_star = PROFITunc(mu, v, p_star, x_star, p_star, x_star, t, sizeb, e);                       % the function PROFITunc(.) computes profit of firm 2 at a possible assymetric combination of p's and x's

% counter = Kp;

for p_index=1:Kp                % looping through values of p
    
    p = pp(p_index); Kp - p_index                           % counter of how many grid points left
    
    for x_index=1:Kx                                        % looping through through values of x
        
        x = xx(x_index);
        pi = PROFITunc(mu, v, p1_fixed, x1_fixed, p, x, t, sizeb,e);        % computes profit at the allocation where firm 1 plays p*,x* and firm 2 plays p,x
        profit(x_index,p_index) = (pi - pi_star)/pi_star;                   % computes the percentage increase in profit at p,x relative to profit at the LSE p*,x* (which is positive since there is market power)
        
    end
    
end


%% contour graph of the deviations

best = max(max(profit));                                                            % determining share profit increase at the best deviation

contour(pp,xx,profit, contours,'ShowText','on');                                    % making a contour plot of iso-profit lines. contours is defined at the beggining
hold on;
scatter(p_star,x_star,'x');
hold off;                                                                           % adding a mark where the LSE is

axis([pmin pmax xmin xmax]);   ylabel('x'); xlabel('p');                              % defining the axes and labelling
title([ 'LSE at t=' num2str(t) ', p*=' num2str(round(p_star*100)/100) ', x*=' num2str(round(x_star*100)/100) ', best % gain=' num2str(round(best*100*100)/100)]);
suptitle('Uncovered Market Non-local Deviations');

set(gcf, 'PaperPosition', [0 0 5 5]); set(gcf, 'PaperSize', [5 5]);
saveas(gcf,'DEVIATIONSuncov.pdf');                                                  % saving the graph


