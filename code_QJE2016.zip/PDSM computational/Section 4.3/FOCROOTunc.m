clear

% finds the LSE values of p*,q* using matlab's fmincon procedure

%% main options

warning('off','all')
e=0.2;                                                                   % moral hazard elasticity
reltol = 1e-2;                                                           % relative tolerance used when evaluating numerical integrals
t1 = [2500:50:10000];  t2 = [11000:1000:50000]; tinput= [t1 t2]';        % input vector of values of market power (t) to be considered
maxtime = 12*60*60/numel(tinput);                                        % maximum time allowed per entry of tinput (makes sure the procedure finishes within 12 hours = 12*60*60 seconds)

opts = optimset('Display','iter','TolX',1e-15,'MaxTime',maxtime,'TolFun',1e-15,'MaxIter',100000, 'MaxFunEvals', 100000,'Algorithm','sqp');      % optimization options


%% creating vectors to be populated with output of the minimization procedures

size_input = numel(tinput);             % size of vector of vector of input values of market power t

RE = NaN(size_input,1);                 % defining generic "empty" vector of the size of the vector of inputs

argmax_x = RE;  argmax_p=RE;            % minimizing values of p and x
FOCS=RE;                                % value of the FOCs at the numerical solution
exit = RE;                              % matlab "exitflag" at the solution
TOL = RE;                               % tolerance used when evaluating integrals
PGUESS = RE;  XGUESS = RE;              % initial guess for p and x
DURATION = RE;                          % time taken to obtain each solution in seconds



%% compute (p*,x*) for each value of t


for i=1:size_input                                  % run the procedure for each value of market power specified above
    
    tic; t = tinput(i)                                   % value of market power t currently being used
    
    p_guess = 5000; x_guess = 0.7;
    
    lb = [0 0]; ub = [0.075 1];                             %upper and lower bounds for optimization
    
    guess = [p_guess*(10^(-6)) x_guess];                    % initial guesses
    PGUESS(i) = p_guess;  XGUESS(i) = x_guess;              % populating the output vector of initial guesses
    
    [argmax, fun_max, exitflag ] = fmincon(@(px) FOCunc(t , px, e, reltol), guess, [],[],[],[], lb , ub, [],opts);       % the function FOCunc is a function of the FOCs, which is minimized
    
    argmax_p(i) = argmax(1)*(10^6); argmax_x(i) = argmax(2);                    % outputs of minimization procedure
    FOCS(i) = fun_max;   exit(i) = exitflag; TOL(i)=reltol;                         % populating the output vectors
    toc; DURATION(i)= toc;                                                        % recording the duration of the optimization procedure
    
    matrix = [tinput argmax_x argmax_p FOCS exit TOL PGUESS XGUESS DURATION];                        % saving a matrix of intermediate outputs
    csvwrite('LSE_inbetween.csv', matrix);
    
end



%% graph of equilibrium (p,x) for each value of t

subplot(2,1,1); semilogx(tinput, argmax_x); xlabel('t'); ylabel('x*');          % graph of x* as a function of t
subplot(2,1,2); semilogx(tinput, argmax_p); xlabel('t'); ylabel('p*');          % graph of p* as a function of t
suptitle(['(x*,p*) for given t, e=' num2str(e)])
set(gcf, 'PaperPosition', [0 0 5 5]); set(gcf, 'PaperSize', [5 5]);                      %Position plot at left hand corner with width 5 and height 5.
saveas(gcf,strcat('LDSEVALUESuncov.pdf'));

matrix = [tinput argmax_x argmax_p FOCS];
csvwrite('LSE.csv', matrix);                                                              % matrix of results


