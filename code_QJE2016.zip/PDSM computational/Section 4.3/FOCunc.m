    function [g] = FOCunc(t , px, e, reltol)
    
    
    % computes FOC at symmetric price and quality vector px, 
    % given market power t, moral hazard elasticity e 
    % and precision reltol
    % it then produces g with is max(|FOC p| , |FOC x| ), which is
    % minimized in the routine FOCROOTunc
    
    
    %% unpacking input vectors
    
    p = px(1)*(10^6);       % changes input to make the optimization sensitive to p
    x = px(2);              % extracting p and x from px

    
    %% integrals over the switching S margin

    % each integral is computed numerically over the set of switching marginal buyers (S)
    % givne the assumption in the paper, this set has the same composition as the set of all buyers
    % which is defined by by mu > mu*, where mu* is the threshold level of mu
    
    % each time, the function inner(.) define the relevant integrand
    
    % each of these 2-dimensional integrals is computed over the full range of (mu,v), while the
    % integrand is multiplied by an indicator function ( mu > mus(v,x,p,e)) 
    % which defined the set of buyers

    inner = @(mu,v) pdf_logn(mu,v,e).*( mu > mus(v,x,p,e) );
    Q = integral2( inner, 0 ,Inf ,0, Inf,'RelTol',reltol);                              % quantity Q
    
    inner = @(mu,v) mc(mu,x,e).*pdf_logn(mu,v,e).*( mu > mus(v,x,p,e) );
    E_mc_S = (1/Q)*integral2( inner, 0 ,Inf ,0, Inf,'RelTol',reltol);                   % average marginal cost E[c'|S]
    
    inner = @(mu,v) c(mu,x,e).*pdf_logn(mu,v,e).*( mu > mus(v,x,p,e) );
    E_c_S = (1/Q)*integral2( inner, 0 ,Inf ,0, Inf,'RelTol',reltol);                    % average cost E[c|S]
    
    inner = @(mu,v) mwtp(mu,v,x,e).*pdf_logn(mu,v,e).*( mu > mus(v,x,p,e) );
    E_mwtp_S = (1/Q)*integral2( inner, 0 ,Inf ,0, Inf,'RelTol',reltol);                 % average marginal willingness to pay E[u'|S]
  
    inner = @(mu,v) mwtp(mu,v,x,e).*c(mu,x,e).*pdf_logn(mu,v,e).*( mu > mus(v,x,p,e) );
    E_mwtp_c_S = (1/Q)*integral2( inner, 0 ,Inf ,0, Inf,'RelTol',reltol);               % average of the product of marginal WTP and cost E[u' * c|S]
    
    
    %% integrals over the exiting X margin
  
    % in this case the indicator function that defines the set of buyers is 
    % (v < vmax );
    
    % these are 1-dimensional integrals over v; at each point the density pdf_logn
    % is evaluated at the exiting marginal type mu*, which is a function of
    % v,x,p,e
    
    vmax = p/((1-((1-x)^2 ))*(1/2));                                                % this is the value of v for which mu_star=0                                                                                           

    integrand = @(v)  pdf_logn(mus(v,x,p,e),v,e).*(v < vmax );  
    MX = (1/(2*x))*integral(integrand, 0, Inf,'RelTol',reltol);                      % the density of the exiting margin, MX; notice I am already dividing by 2x
    
    integrand = @(v) c(mus(v,x,p,e),x,e).*pdf_logn(mus(v,x,p,e),v,e).*(v < vmax );  
    E_c_X = (1/MX) * integral(integrand, 0, Inf,'RelTol',reltol);                   % average of cost E[c|X]
 
    integrand = @(v) mwtp(mus(v,x,p,e),v,x,e).*pdf_logn(mus(v,x,p,e),v,e).*(v < vmax );  
    E_mwtp_X = (1/MX) * integral(integrand, 0, Inf,'RelTol',reltol);                    % average of marginal willingness to pay E[u'|X]
     
    integrand = @(v) mwtp(mus(v,x,p,e),v,x,e).*c(mus(v,x,p,e),x,e).*pdf_logn(mus(v,x,p,e),v,e).*(v < vmax );  
    E_mwtp_c_X = (1/MX) * integral(integrand, 0, Inf,'RelTol',reltol);                  % average of the product of marginal WTP and cost, E[u' * c|X]
    
    
    %% FOC ingredients

    MS = Q/(2*t);                                       % density of the switching margin

    M = MX + MS;                                        % total density of the margin

    cov_S = E_mwtp_c_S - (E_mwtp_S * E_c_S);            % covariance conditional on the switching margin S

    cov_X = E_mwtp_c_X - (E_mwtp_X * E_c_X);            % covariance conditional on the exiting margin X

    cov = MS*cov_S + MX*cov_X;                          % overall covariance conditional on both margins

    marginal_cost =  (MS*E_c_S + MX*E_c_X )/M;               % marginal cost (average of cost conditional on the margins)

    markup = (1/2)*(Q/M);                                   % markup above marginal cost

    E_up_margin = (MS*E_mwtp_S + MX*E_mwtp_X)/M;            % expectation of u' over all the margins E[u' | M]
    
    
    %% First Order Conditions (FOCs)

    focp = p - marginal_cost - markup;              % FOC with respect to p
    
    focx = (1/2)*Q*(E_up_margin - E_mc_S) - cov;        % FOC with respect to x
    
    g = max( abs(focp) , abs(focx)) ;                   % function of the FOCs that is minimized in the routine FOCROOTunc: this is the max of the absolute values of the FOCs


end

