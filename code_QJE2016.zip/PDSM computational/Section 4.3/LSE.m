function [ PI, Q, WELFARE, CS, AC ] = LSE(p,x,e, reltol)


% this function takes as inputs the symmetric LSE values of p and x
% (along with moral hazard elasticity e and tolerance reltol)
% and outputs several LSE statistics suchs as
% market share Q, profit PI, welfare WELFARE, consumer surplus CS and
% average cost AC

% each time the function inner(.) defines the integrand that is being
% evaluated; the 2-dimensional integrals are evaluated over the full range of mu and v;
% the set of buyers is defined by the indicator function ( mu > mus(v,x,p,e) )


%% quantity/market coverage Q

inner = @(mu,v) pdf_logn( mu, v,e).*( mu > mus(v,x,p,e) );
Q = integral2( inner, 0 ,Inf ,0, Inf,'RelTol',reltol);

%%  total cost

inner = @(mu,v) c(mu,x,e).*pdf_logn( mu, v,e).*( mu > mus(v,x,p,e) );
C = integral2( inner, 0 ,Inf ,0, Inf,'RelTol',reltol);

%% average cost

AC=C/Q;                     

%% profit 

PI = Q*p - C;

%% consumer surplus

inner = @(mu,v) wtp(x,mu,v,e) .*pdf_logn( mu, v,e).*( mu > mus(v,x,p,e) );
CS = integral2( inner, 0 ,Inf ,0, Inf,'RelTol',reltol);
CS = CS - Q*p;                                  % subtract total payments Q*p


%% welfare 

WELFARE = CS + PI;


end

