%% MASTER FILE

% This script produces all the output for Section 4.3 (Competition in Insurance) in
% "Product Design in Selection Markets"
% by Andre Veiga and E. Glen Weyl

%% disclaimer

% the individual scripts should be ran in this sequence, since later scripts use the
% output of earlier scripts as inputs


%% Main Scripts

Wmax                    % computes the welfare maximizing levels of (p,x) with moral hazard



FOCROOTunc              % finding the solutions of the FOCs in an uncovered market



MARKETPOWERuncv         % uses FOC solutions to produce the graphs of welfare, consumer surplus, etc for different levels of market power



DEVIATIONSunc           % computes non-local deviations from the local equilibrium which maximizes welfare


