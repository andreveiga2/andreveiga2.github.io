clear


%% setup

e=0.2;              % moral hazard elasticity
reltol=1e-3;        % tolerance when computing numerical integrals
bh=1;               % behavioral coefficient (bh=1 means neoclassical consumers)

%% importing welfare maximizing values of p,x & computing properties of welfare maximizing allocation

Wmax = csvread('Wmax.csv');                 % importing files with welfare maximizing contract
p_wmax = Wmax(1);
x_wmax = Wmax(2);
[ pi_wmax, q_wmax, welf_wmax, cs_wmax, ac_wmax ] = LSE(p_wmax, x_wmax, e, reltol);        %  the function LSE computes several properties of any LSE, such as profit, quantity, etc


%% importing values that maximizes behavioral welfare

Wmax_bh = csvread('Wmax_bh.csv');                   % importing files with behavioral welfare maximizing contract
p_wmax_bh = Wmax_bh(1);
x_wmax_bh = Wmax_bh(2);

px = [p_wmax_bh*(10^-6), x_wmax_bh];                % producing vector of behavioral welfare maximizing p,x
welf_bh_max = welf( px, e, reltol, 0.0537);         %   computing welfare at the behavioral welfare maximizing contract, using behavioral coefficient bh = 0.0537;



%% importing values of LSE computed for each level of market power

LSEinput = csvread('LSE.csv');                             % importing file with LSE values for different levels of market power t

tinput=LSEinput(:,1);                                       % LSE level of t
xinput=LSEinput(:,2);                                        % LSE level of x
pinput=LSEinput(:,3);                                   % LSE level of p
FOCinput=LSEinput(:,4);                                 % LSE level of g = max(|FOC p|,|FOC x|)

FOCtolerance = 10;                                          % tolerance for level of g = max(|FOC p|,|FOC x|) at the solution for each value of market power t
tinput(FOCinput > FOCtolerance)=[];                         % removing entries for which the FOC, evaluted at that point, is too large
xinput(FOCinput > FOCtolerance)=[];
pinput(FOCinput > FOCtolerance)=[];


min_existence = 3450;                                     % the lowest level of market power for which the Second Order Conditions hold and g is sufficiently small is t = 3450
clone_tinput = tinput;                                    % creating a copy of the vector tinput, to be used as a reference in eliminating those entries for which SOC does not hold
tinput(clone_tinput <= min_existence)=[];
xinput(clone_tinput <= min_existence)=[];
pinput(clone_tinput <= min_existence)=[];
FOCinput(clone_tinput <= min_existence)=[];



%% making graph of clean LSE values (removing those for which converge was poor)

subplot(2,1,1); semilogx(tinput, xinput,'-o'); xlabel('t'); ylabel('x*');
title(['Removed points where Max[|FOCp|,|FOCx|]>' num2str(FOCtolerance) ' or t<' num2str(min_existence)])
subplot(2,1,2); semilogx(tinput, pinput,'-o'); xlabel('t'); ylabel('p*');
suptitle(['(x*,p*) for given t, e=' num2str(e)])
set(gcf, 'PaperPosition', [0 0 5 5]); set(gcf, 'PaperSize', [5 5]);                      %Position plot at left hand corner with width 5 and height 5.
saveas(gcf,strcat('LDSEVALUESuncov_clean.pdf'));



%% defining vectors to be populated later to produce graphs

RE = NaN(numel(tinput),1);                              % defining generic vector size of vectors to be created
www = RE; ccc = RE;                                     % defining "empty" vectors with values of welfare, consumer surplus as shares of their first best values
xxx = RE; ppp = RE;                                     % defining "empty" vectors with values of profit (ppp) , and quality x
qqq = RE; rrr = RE; ttt=RE;                             % defining "empty" vectors with values of quantity q, relative markup R, and market power t
WWW = RE; CCC = RE; WWWB = RE;                          % defining "empty" vectors with absolute values of welfare, consumer surplus and beharioral welfare
w_eq = RE; wwwb = RE;                                   % defining "empty" vectors with values of welfare and behavioral welfare at the first best



%% compute outcomes for each equilibrium

for i=1:numel(tinput)                       %looping through the values of market power t in the vector tinput
    
    t = tinput(i)                                   % level of market power currently under consideration
    p_eq = pinput(i); x_eq = xinput(i);             % importing the corresponding values of equilibrium p and x
    
    [ pi_eq, q_eq, w_eq, cs_eq, ac_eq ] = LSE(p_eq, x_eq, e, reltol);     % market outcomes at this LSE; the function LSE(.) computes profit, quantity, etc at a given symmetric LSE
    
    % populating vectors later used to make graph
    ttt(i) = t;                                                 % market power
    qqq(i) = q_eq;                                              % LSE values of quantity/market coverage q
    xxx(i) = x_eq;                                              % LSE values of quality x
    ppp(i) = pi_eq;                                             % LSE values of profit
    
    rrr(i) = ( p_eq - ac_eq )/ac_eq;                % % LSE values of relative markup R; ac_eq is the average cost at equilibrium
    
    WWW(i) = w_eq;                                  % LSE values of total realized welfare
    www(i) = WWW(i)/welf_wmax;                      % LSE values of welfare as share of Wmax (welfare at the contract that maximizes welfare)
    
    CCC(i) = cs_eq;                                 % LSE values of total realized consumer surplus
    ccc(i) = cs_eq/cs_wmax;                         % LSE values of consumer surplus as share of CSmax (consumer surplus at the contract that maximizes welfare)
    
    z = [pinput(i)*(10^-6) xinput(i)];              % creating vector of inputs to compute behavioral welfare at the LSE under consideration
    WWWB(i) = welf( z, e, reltol, 0.0537);          % LSE values of total realized behavioral welfare
    wwwb(i) = WWWB(i)/welf_bh_max;                  % LSE values of behavioral welfare as share of Welf_bh_max (behavioral welfare at the contract that maximizes behavioral welfare)
    
end



%% plot of results against relative markup R

clf
plot(rrr, qqq,'-o', rrr, xxx,'-x'); xlabel('R');                                            % plot of LSE market coverage q and quality x
suptitle(['Effects of market power, e=' num2str(e)])
title(['p**=' num2str(p_wmax) ', x**=' num2str(round(x_wmax*100)/100)])
legend('q*','x*','Location','Best');
set(gcf, 'PaperPosition', [0 0 5 5]);set(gcf, 'PaperSize', [5 5]);                                                  %Position plot at left hand corner with width 5 and height 5
saveas(gcf,strcat('plot_vs_R1.pdf'));


clf
plot(rrr, www,'-o', rrr, ccc,'-x', rrr, wwwb,'-s'); xlabel('R');                            % plot of welfare quantities (neoclassical and behavioral) and neoclassical consumer surplus
suptitle(['Effects of market power, e=' num2str(e)])
title(['p**=' num2str(p_wmax) ', x**=' num2str(round(x_wmax*100)/100) '   |   p**_{b}=' num2str(round(p_wmax_bh*100)/100) ', x**_{b}=' num2str(round(x_wmax_bh*100)/100)])
legend('W*/W**','CS*/CS**','W*_{b}/W_{b}**','Location','Best');
set(gcf, 'PaperPosition', [0 0 5 5]);set(gcf, 'PaperSize', [5 5]);                                                  %Position plot at left hand corner with width 5 and height 5
saveas(gcf,strcat('plot_vs_R2.pdf'));



%% saving all results into a (CSV file) matrix

matrix = [ttt xinput pinput qqq rrr www ccc wwwb];
csvwrite( strcat('MARKETPOWERdata.csv'), matrix);



