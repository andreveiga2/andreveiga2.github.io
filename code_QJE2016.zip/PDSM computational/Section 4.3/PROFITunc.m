function [ PROFIT1 ] = PROFITunc(mu, v, p0, x0, p1, x1, t, size_b, e)


% computes several quantities for asymmetric p,x
% takes in any vector of mu,v
% for each type (mu,v), a number size_b of replicas are created with
% different values of b
% moral hazard elasticity is e



%% augmenting types 

b = linspace(1/size_b, 1-(1/size_b), size_b)';          % size_b equally spaced values on the interior of (0,1)

types = NaN(numel(mu)*size_b, 3);                       % empty matrix to be populated with the augmented types


for g=1:numel(mu)                       % loop thorugh types (m,v)
    
    mm = mu(g)*ones(size_b,1);          % extracts the values of mu and v for the g-th user
    vv = v(g)*ones(size_b,1);
    
    types( (g-1)*size_b + 1 : g*size_b, 1 )=mm; % creates size_b copies of the g-th value of mu
    types( (g-1)*size_b + 1 : g*size_b, 2 )=vv; % creates size_b copies of the g-th value of v
    types( (g-1)*size_b + 1 : g*size_b, 3 )=b;  % creates size_b vlaues of v for the value of (mu,v) under consideration
    
end

mu = types(:,1); v = types(:,2); b = types(:,3);          % redefining types
 
total = numel(mu);         % total number of resulting types, after augmentation

%% defining utility for each insurer

u0 = wtp(x0, mu, v, e) - p0;        % for each consumer, utility is the difference between WTP and price
u1 = wtp(x1, mu, v, e) - p1;            

%% creating vectors to be populated

RE = NaN(total,1); 
buy0 = RE;                  
buy1 = RE;                      % vector of purchasing decisions (=1 if consumer buys from firm 1, =0 otherwise)
U0 = RE; U1 = RE;               % vectors of resulting utilities


%% determining the final utilities (including travel costs) and purchase decisions for each user

for i=1:numel(mu)           % loop through each type (mu,v,b)

    
    % first, augment utility of consumer i with the travel costs; to purchase
    % from the furthest insurer, U = u + travels costs; otherwise U=u
    % therefore U, not u, is total utility taking into account travel costs
    if b(i) >= 1/2
        U0(i) = u0(i) - t*( 2*b(i) -1);
        U1(i) = u1(i);              % this is the total willingness to pay for firm 1 - it includes travel costs for consumer is located closer to firm 0, ie at b>1/2
    elseif b(i) <= 1/2
         U0(i) = u0(i);
         U1(i) = u1(i) - t*(1 - 2*b(i) );
    end
    
    
    % computing purchase decision for consumer i
    if U1(i)>=max(0,U0(i))          % condition implying pruchase from firm 1
       buy1(i) = 1;                 % populating the vectors of purchase decisions
       buy0(i) = 0;
    end
    
    if U0(i)>=max(0, U1(i))         % condition implying pruchase from firm 0
        buy1(i) = 0;
        buy0(i) = 1;
    end
    
    
    if 0>=max( U0(i), U1(i))        % condition implying the consumer does not purchase insurance
       buy0(i)=0; 
       buy1(i)=0; 
    end
    
end


%% profit by the deviating firm

individual_pi1 = p1 - c(mu, x1, e);                 % contribution to profit of firm 1 by each individual
PROFIT1 = mean(buy1.*individual_pi1);               % integral of individual contributions to profit by all the buyers of firm 1 (hence the indicator function buy1)


end


