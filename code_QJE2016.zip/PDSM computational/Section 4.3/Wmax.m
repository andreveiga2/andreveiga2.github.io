%% welfare maximiziation


% this file computes the (p,x) that maximizes neoclassical welfare
% and maximizes behavioral welfare

clear


%% setup

reltol = 1e-3;              % relative tolerance used when integrating functions
e=0.2;                      % moral hazard elasticity

opts = optimset('Display','iter','TolX',1e-15,'TolFun',1e-15,'MaxIter',5000, 'MaxFunEvals', 5000,'Algorithm','sqp');    % optimization options



%% neoclassical welfare

% this routine follows the one above, changing only the behavioral coefficient which now is bh=1

bh = 1;                                                 % in this case, the behavioral coefficient is 1
lb = [0 0]; ub = [1 1];                                 % upper and lower bounds for optimization

p_guess = 1000; x_guess = 0.9;
guess = [p_guess*(10^(-6)) x_guess];                          % initial guess

[argmax, ~, ~ ] = fmincon( @(px) -welf( px, e, reltol, bh), guess, [],[],[],[], lb , ub, [], opts)     % maximization of neoclassical welfare

p_wmax = argmax(1)*(10^6)
x_wmax = argmax(2)                                      %solutions to the maximization routine

[ pi_wmax, q_wmax, w_wmax, cs_wmax, ac_wmax ] = LSE(p_wmax, x_wmax, e, reltol);

matrix = [p_wmax x_wmax q_wmax e bh];
csvwrite('Wmax.csv', matrix);                               % saving output: p x and q at the welfare maximum




%% behavioral welfare

bh = 0.0537;                                            % ratio of behavioral insurance value to neoclassical insurance value, obtained from Handel & Kolstad 2015 "Health Insurance for "Humans": Information Frictions, Plan Choice, and Consumer Welfare"

lb = [0 0]; ub = [1 1];                                 % upper and lower bounds for (p,x)
p_guess = 3000; x_guess = 0.6;                          % initial guesses for (p,x)
guess = [p_guess*(10^(-6)) x_guess];                    % compiling initial guesses into a single vector; price is multiplied by 10^-6 so it is of a similar order of magnitude to x, which helps the optimization procedure

[argmax, ~, ~ ] = fmincon( @(px) -welf( px, e, reltol, bh), guess, [],[],[],[], lb , ub, [], opts)                % maximizing welfare; the function welf(.) computes welfare for a given (p,x) and the behavioral coefficient bh

p_wmax = argmax(1)*(10^6)
x_wmax = argmax(2)                                      % compiles the solutions of the optimization procedure

[ pi_wmax, q_wmax, w_wmax, cs_wmax, ac_wmax ] = LSE(p_wmax, x_wmax, e, reltol);

matrix = [p_wmax x_wmax q_wmax bh];                          % matrix of results, including the chosen level of MH and behavioral coefficient bh
csvwrite('Wmax_bh.csv', matrix);                        % saving output into a csv file; this file will be read by a later routine to produce the graph of welfare, etc as a function of market power



