function [ cost ] = c(mu,x,e)

% cost to the insurer of providing coverage x to an individual of type mu, when 
% moral hazard elasticity is e

cost = mu * x * ( (1-x)^(-e) ) ; 

end

