function [mu, v] = consumers(K)

% simulates K^2 consumers according to correlation parameter rho

%% creating vectors of types to be populated later

mu  = NaN(K^2,1);                         %buying real estate for K^2 consumers with 2D types
v   = NaN(K^2,1);

%% defining major parameters

e=0.2;                          % moral hazard elasticity
xhat =0.86;                     % representative level of coverage in the HHW data is x=.86
alpha = log( (1 - xhat )^e );   % correction factor by which we multiply the mu types derived directly from the HHW statistics, to account for moral hazard

%% generating types 

uu = linspace( 1/K, 1-(1/K), K)';                       % vector of K evenly spaced points on the interior of (0,1); these will be used to draw from the appropriate inverse CDFs to generate types

mean_v = 11;                    % mean of v
var_v = 1.2;                    % variance of v
sd_v = sqrt(var_v);             % standard deviation of v

v_base = logninv(uu, mean_v, sd_v);         % the baseline vector of values of v; for each of these values, the script below will generate the conditional distribution of mu|v

for k=1:K               % looping through the K values of v
    
    
    plugin_v = v_base(k)*ones(K,1);             % selecting the K-th value of v; creating K replicas of it
    v( K*(k-1)+1 : K*k, 1) = plugin_v;          % plugging the vector above into the final vector of types v     
    
    this_v = v_base(k);                         % scalar captures the current value of v under consideration
    
    mean_mu__v  = 8.4 + (.53)*(log(this_v) - 11) + alpha ;          % mean of mu conditional on the value of v under consideration, taking into account the moral hazard correction through the term alpha
    sd_mu__v    = 0.43;                                             % variance of mu conditional on v

    plugin_mu = logninv(uu, mean_mu__v, sd_mu__v);              % values of mu, conditional on the value of v currently under consideration, obtained by drawing from the inverse CDF of mu conditional on v
    
    mu( K*(k-1)+1 : K*k , 1) = plugin_mu ;                   % plugging the resulting vector of mu into the final vector of types, mu     
    
end


end

