function [ y ] = g(x)

% this function gives the risk premium associated with a given value
% of x, for an individual with v=1

y = ( 1- ( (1-x)^2 ))*(1/2);

end

