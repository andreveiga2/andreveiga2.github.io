




% graph of delta_u as a function of gamma
cla;clf;
scatter(gamma,delta_u,[],decisions); xlabel('gamma'); title('\Delta u and \gamma')
set(gcf, 'PaperPosition', [0 0 5 5]); set(gcf, 'PaperSize', [5 5]);
saveas(gcf,strcat(['delta_u_gamma.pdf']));



% graph of types and purchase decisions
Q = mean(decisions);
scatter(alpha, gamma,[], decisions,'x');
xlabel('\alpha'); ylabel('\gamma')
suptitle([ 'Share ' num2str(Q) ' buy H annuity at p=' num2str(p)]);
title(['E[\alpha]=' num2str(mean(alpha)) '  E[\gamma]=' num2str(mean(gamma)) ...
    ' correlation=' num2str(corr(alpha,gamma)) ' \beta=' num2str(beta) ' inflation=' num2str(inflation)])
set(gcf, 'PaperPosition', [0 0 5 5]); set(gcf, 'PaperSize', [5 5]);
