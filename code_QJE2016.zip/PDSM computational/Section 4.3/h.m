function [ y ] = h(x,e)

% benefit to the individual of obtain coverage x, when type is mu=1
% and moral hazard elasticity is e

y =  ( 1/(1-e) ) * ( 1 - ( (1-x)^(1-e) ) );  

end

