function [ marginal_cost ] = mc(mu,x,e)

% this function outputs the marginal cost for an individual of type mu, given coverage x, when
% moral hazard is e


% recall: cost is  mu*x*((1-x)^(-e)) ;

marginal_cost = mu*((1-x)^(-e)) + mu*x*(-e)*((1-x)^(-e-1))*(-1);


end

