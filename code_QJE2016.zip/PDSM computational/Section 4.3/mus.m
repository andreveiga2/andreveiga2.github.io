function [ y ] = mus( v, x, p, e )

% this function outputsthe threshold type mu for each v and x
% it takes into account that the threshold type is mu=0 when v is sufficiently large
% it uses the moral hazard cost function h(.) and the risk premium function g(.)

 y = max( (1/h(x,e) ) * ( p - g(x)*v ), 0);


end

