function [ up ] = mwtp(mu,v,x,e)

% this function gives the marginal willingness to pay for x for a consumer
% of type mu,v
% the moral hazard elasticity is e

up = mu*((1-x)^(-e)) + (1-x)*v;

end

