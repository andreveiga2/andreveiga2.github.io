function [ pdf ] = pdf_logn( mu, v,e)

% this function computes the pdf of the bivariate lognormal at the point
% (mu,v), based on the summary statistics of the HHW market, taking into
% account that moral hazard elasticity is e.

%% accounting for moral hazard

xhat = 0.86;                % representative elvel of coverage in the HHW market is x=.86
alpha = (1 - xhat )^e ;     % factor used to correct types mu generated from the HHW statistics

%% summary statistics of the HHW market

sd_mu__v = 0.43;                    % standard deviation of mu conditional on v
mean_v = 11;                            % mean of v
var_v = 1.2;                            % variance of v
sd_v = sqrt(var_v);                   % standard deviation of v

%% computing the joint PDF f(mu,v) = f(mu|v)*f(v)

pdf_v = lognpdf(v, mean_v, sd_v);           % marginal pdf of v (unconditional)

pdf_mu__v = lognpdf(mu, 8.4 + 0.53*(log(v)-11) + log(alpha), sd_mu__v );        % marginal pdf of mu conditional on v

pdf = pdf_v.*pdf_mu__v;             % joint pdf of (mu,v)

end


