function [ welf ] = welf( px, e, reltol, bh)


% computes welfare at a symmetric local equilibrum (p,x), 
% where bh is the behavioral bias and
% reltol is the relative tolerance used when computing the integrals
% numerically


%% setup
x = px(2); p = px(1)*(10^6);         % unpacking the vector px into its components p and x
                                     % price is passed to this function
                                     % multiplied by 10^-6 so it is of a similar order of magnitude to x 


%% integrals

% integrals are computed over the set of buyers, defined as mu > mu*, where mu* is the threshold level of mu for each v,x,p,e
% each integral uses the function pdf_logn which computes the pdf of the
% bivariate lognormal at the required point
% the function wtp(.) gives willingness to pay at each point
% the function c(.) gives individual cost at each point

inner = @(mu,v) wtp(x,mu,v*bh,e).*pdf_logn( mu, v, e).*( mu > mus(v,x,p,e) );       % computing the integral of WTP over the set of buyers
WTP = integral2( inner, 0 ,Inf ,0, Inf,'RelTol',reltol);

inner = @(mu,v) c(mu,x,e).*pdf_logn( mu, v,e).*( mu > mus(v,x,p,e) );               % computing the integral of cost over the set of buyers
C = integral2( inner, 0 ,Inf ,0, Inf,'RelTol',reltol);

%% wefare

welf = WTP - C;
     
end

