function y = wtp(x, mu, v, e)

% willingness to pay, where h(.) captures moral hazard nad g(.) captures
% the risk premium


y =  mu*h(x,e) + g(x)*v;



end

